/* Include files */

#include "blascompat32.h"
#include "conver_PMSM_guangzhou_smo_sfun.h"
#include "c6_conver_PMSM_guangzhou_smo.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance.chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance.instanceNumber)
#include "conver_PMSM_guangzhou_smo_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */
#define c6_IN_NO_ACTIVE_CHILD          (0)

/* Variable Declarations */

/* Variable Definitions */
static SFc6_conver_PMSM_guangzhou_smoInstanceStruct chartInstance;

/* Function Declarations */
static void initialize_c6_conver_PMSM_guangzhou_smo(void);
static void initialize_params_c6_conver_PMSM_guangzhou_smo(void);
static void enable_c6_conver_PMSM_guangzhou_smo(void);
static void disable_c6_conver_PMSM_guangzhou_smo(void);
static void c6_update_debugger_state_c6_conver_PMSM_guangzhou_smo(void);
static const mxArray *get_sim_state_c6_conver_PMSM_guangzhou_smo(void);
static void set_sim_state_c6_conver_PMSM_guangzhou_smo(const mxArray *c6_st);
static void finalize_c6_conver_PMSM_guangzhou_smo(void);
static void sf_c6_conver_PMSM_guangzhou_smo(void);
static void init_script_number_translation(uint32_T c6_machineNumber, uint32_T
  c6_chartNumber);
static const mxArray *c6_sf_marshall(void *c6_chartInstance, void *c6_u);
static void c6_info_helper(c6_ResolvedFunctionInfo c6_info[38]);
static const mxArray *c6_emlrt_marshallOut(uint8_T c6_u);
static real_T c6_emlrt_marshallIn(const mxArray *c6_pi2, char *c6_name);
static uint8_T c6_b_emlrt_marshallIn(const mxArray
  *c6_b_is_active_c6_conver_PMSM_guangzhou_smo, char *c6_name);
static void init_io_bus_offset(void);
static void init_dsm_address_info(void);

/* Function Definitions */
static void initialize_c6_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
  chartInstance.c6_is_active_c6_conver_PMSM_guangzhou_smo = 0U;
}

static void initialize_params_c6_conver_PMSM_guangzhou_smo(void)
{
}

static void enable_c6_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
}

static void disable_c6_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
}

static void c6_update_debugger_state_c6_conver_PMSM_guangzhou_smo(void)
{
}

static const mxArray *get_sim_state_c6_conver_PMSM_guangzhou_smo(void)
{
  const mxArray *c6_st = NULL;
  const mxArray *c6_y = NULL;
  real_T c6_u;
  const mxArray *c6_b_y = NULL;
  real_T *c6_pi2;
  c6_pi2 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  c6_st = NULL;
  c6_y = NULL;
  sf_mex_assign(&c6_y, sf_mex_createcellarray(2));
  c6_u = *c6_pi2;
  c6_b_y = NULL;
  sf_mex_assign(&c6_b_y, sf_mex_create("y", &c6_u, 0, 0U, 0U, 0U, 0));
  sf_mex_setcell(c6_y, 0, c6_b_y);
  sf_mex_setcell(c6_y, 1, c6_emlrt_marshallOut
                 (chartInstance.c6_is_active_c6_conver_PMSM_guangzhou_smo));
  sf_mex_assign(&c6_st, c6_y);
  return c6_st;
}

static void set_sim_state_c6_conver_PMSM_guangzhou_smo(const mxArray *c6_st)
{
  const mxArray *c6_u;
  real_T *c6_pi2;
  c6_pi2 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  chartInstance.c6_doneDoubleBufferReInit = true;
  c6_u = sf_mex_dup(c6_st);
  *c6_pi2 = c6_emlrt_marshallIn(sf_mex_dup(sf_mex_getcell(c6_u, 0)), "pi2");
  chartInstance.c6_is_active_c6_conver_PMSM_guangzhou_smo =
    c6_b_emlrt_marshallIn(sf_mex_dup(sf_mex_getcell(c6_u, 1)),
    "is_active_c6_conver_PMSM_guangzhou_smo");
  sf_mex_destroy(&c6_u);
  c6_update_debugger_state_c6_conver_PMSM_guangzhou_smo();
  sf_mex_destroy(&c6_st);
}

static void finalize_c6_conver_PMSM_guangzhou_smo(void)
{
}

static void sf_c6_conver_PMSM_guangzhou_smo(void)
{
  uint8_T c6_previousEvent;
  real_T c6_theta;
  real_T c6_nargout = 1.0;
  real_T c6_nargin = 1.0;
  real_T c6_pi2;
  real_T c6_x;
  real_T c6_b_x;
  real_T c6_xk;
  real_T c6_c_x;
  real_T c6_d_x;
  real_T c6_b;
  real_T c6_y;
  real_T c6_e_x;
  real_T c6_f_x;
  real_T c6_g_x;
  real_T c6_h_x;
  real_T c6_b_y;
  real_T c6_i_x;
  real_T c6_j_x;
  real_T *c6_b_pi2;
  real_T *c6_b_theta;
  c6_b_theta = (real_T *)ssGetInputPortSignal(chartInstance.S, 0);
  c6_b_pi2 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,5);
  _SFD_DATA_RANGE_CHECK(*c6_b_theta, 0U);
  _SFD_DATA_RANGE_CHECK(*c6_b_pi2, 1U);
  c6_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,5);
  c6_theta = *c6_b_theta;
  sf_debug_symbol_scope_push(4U, 0U);
  sf_debug_symbol_scope_add("nargout", &c6_nargout, c6_sf_marshall);
  sf_debug_symbol_scope_add("nargin", &c6_nargin, c6_sf_marshall);
  sf_debug_symbol_scope_add("pi2", &c6_pi2, c6_sf_marshall);
  sf_debug_symbol_scope_add("theta", &c6_theta, c6_sf_marshall);
  CV_EML_FCN(0, 0);
/* ====