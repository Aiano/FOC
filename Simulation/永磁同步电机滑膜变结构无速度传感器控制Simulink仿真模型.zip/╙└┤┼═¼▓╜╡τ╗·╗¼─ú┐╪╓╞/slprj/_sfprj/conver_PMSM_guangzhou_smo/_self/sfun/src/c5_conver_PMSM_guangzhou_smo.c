/* Include files */

#include "blascompat32.h"
#include "conver_PMSM_guangzhou_smo_sfun.h"
#include "c5_conver_PMSM_guangzhou_smo.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance.chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance.instanceNumber)
#include "conver_PMSM_guangzhou_smo_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */
#define c5_IN_NO_ACTIVE_CHILD          (0)

/* Variable Declarations */

/* Variable Definitions */
static SFc5_conver_PMSM_guangzhou_smoInstanceStruct chartInstance;

/* Function Declarations */
static void initialize_c5_conver_PMSM_guangzhou_smo(void);
static void initialize_params_c5_conver_PMSM_guangzhou_smo(void);
static void enable_c5_conver_PMSM_guangzhou_smo(void);
static void disable_c5_conver_PMSM_guangzhou_smo(void);
static void c5_update_debugger_state_c5_conver_PMSM_guangzhou_smo(void);
static const mxArray *get_sim_state_c5_conver_PMSM_guangzhou_smo(void);
static void set_sim_state_c5_conver_PMSM_guangzhou_smo(const mxArray *c5_st);
static void finalize_c5_conver_PMSM_guangzhou_smo(void);
static void sf_c5_conver_PMSM_guangzhou_smo(void);
static void c5_c5_conver_PMSM_guangzhou_smo(void);
static void init_script_number_translation(uint32_T c5_machineNumber, uint32_T
  c5_chartNumber);
static void c5_eml_warning(void);
static const mxArray *c5_sf_marshall(void *c5_chartInstance, void *c5_u);
static void c5_info_helper(c5_ResolvedFunctionInfo c5_info[24]);
static const mxArray *c5_emlrt_marshallOut(uint8_T c5_u);
static real_T c5_emlrt_marshallIn(const mxArray *c5_theta, char *c5_name);
static real_T c5_b_emlrt_marshallIn(const mxArray *c5_thetaCom, char *c5_name);
static uint8_T c5_c_emlrt_marshallIn(const mxArray
  *c5_b_is_active_c5_conver_PMSM_guangzhou_smo, char *c5_name);
static void init_io_bus_offset(void);
static void init_dsm_address_info(void);

/* Function Definitions */
static void initialize_c5_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
  chartInstance.c5_is_active_c5_conver_PMSM_guangzhou_smo = 0U;
}

static void initialize_params_c5_conver_PMSM_guangzhou_smo(void)
{
}

static void enable_c5_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
}

static void disable_c5_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
}

static void c5_update_debugger_state_c5_conver_PMSM_guangzhou_smo(void)
{
}

static const mxArray *get_sim_state_c5_conver_PMSM_guangzhou_smo(void)
{
  const mxArray *c5_st = NULL;
  const mxArray *c5_y = NULL;
  real_T c5_u;
  const mxArray *c5_b_y = NULL;
  real_T c5_b_u;
  const mxArray *c5_c_y = NULL;
  real_T *c5_theta;
  real_T *c5_thetaCom;
  c5_theta = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  c5_thetaCom = (real_T *)ssGetOutputPortSignal(chartInstance.S, 2);
  c5_st = NULL;
  c5_y = NULL;
  sf_mex_assign(&c5_y, sf_mex_createcellarray(3));
  c5_u = *c5_theta;
  c5_b_y = NULL;
  sf_mex_assign(&c5_b_y, sf_mex_create("y", &c5_u, 0, 0U, 0U, 0U, 0));
  sf_mex_setcell(c5_y, 0, c5_b_y);
  c5_b_u = *c5_thetaCom;
  c5_c_y = NULL;
  sf_mex_assign(&c5_c_y, sf_mex_create("y", &c5_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_setcell(c5_y, 1, c5_c_y);
  sf_mex_setcell(c5_y, 2, c5_emlrt_marshallOut
                 (chartInstance.c5_is_active_c5_conver_PMSM_guangzhou_smo));
  sf_mex_assign(&c5_st, c5_y);
  return c5_st;
}

static void set_sim_state_c5_conver_PMSM_guangzhou_smo(const mxArray *c5_st)
{
  const mxArray *c5_u;
  real_T *c5_theta;
  real_T *c5_thetaCom;
  c5_theta = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  c5_thetaCom = (real_T *)ssGetOutputPortSignal(chartInstance.S, 2);
  chartInstance.c5_doneDoubleBufferReInit = true;
  c5_u = sf_mex_dup(c5_st);
  *c5_theta = c5_emlrt_marshallIn(sf_mex_dup(sf_mex_getcell(c5_u, 0)), "theta");
  *c5_thetaCom = c5_b_emlrt_marshallIn(sf_mex_dup(sf_mex_getcell(c5_u, 1)),
    "thetaCom");
  chartInstance.c5_is_active_c5_conver_PMSM_guangzhou_smo =
    c5_c_emlrt_marshallIn(sf_mex_dup(sf_mex_getcell(c5_u, 2)),
    "is_active_c5_conver_PMSM_guangzhou_smo");
  sf_mex_destroy(&c5_u);
  c5_update_debugger_state_c5_conver_PMSM_guangzhou_smo();
  sf_mex_destroy(&c5_st);
}

static void finalize_c5_conver_PMSM_guangzhou_smo(void)
{
}

static void sf_c5_conver_PMSM_guangzhou_smo(void)
{
  uint8_T c5_previousEvent;
  real_T *c5_al;
  real_T *c5_be;
  real_T *c5_theta;
  real_T *c5_frun;
  real_T *c5_fcutoff;
  real_T *c5_thetaCom;
  c5_frun = (real_T *)ssGetInputPortSignal(chartInstance.S, 2);
  c5_theta = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  c5_al = (real_T *)ssGetInputPortSignal(chartInstance.S, 0);
  c5_thetaCom = (real_T *)ssGetOutputPortSignal(chartInstance.S, 2);
  c5_be = (real_T *)ssGetInputPortSignal(chartInstance.S, 1);
  c5_fcutoff = (real_T *)ssGetInputPortSignal(chartInstance.S, 3);
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,4);
  _SFD_DATA_RANGE_CHECK(*c5_al, 0U);
  _SFD_DATA_RANGE_CHECK(*c5_be, 1U);
  _SFD_DATA_RANGE_CHECK(*c5_theta, 2U);
  _SFD_DATA_RANGE_CHECK(*c5_frun, 3U);
  _SFD_DATA_RANGE_CHECK(*c5_fcutoff, 4U);
  _SFD_DATA_RANGE_CHECK(*c5_thetaCom, 5U);
  c5_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  c5_c5_conver_PMSM_guangzhou_smo();
  _sfEvent_ = c5_previousEvent;
  sf_debug_check_for_state_inconsistency
    (_conver_PMSM_guangzhou_smoMachineNumber_, chartInstance.chartNumber,
     chartInstance.
     instanceNumber);
}

static void c5_c5_conver_PMSM_guangzhou_smo(void)
{
  real_T c5_al;
  real_T c5_be;
  real_T c5_frun;
  real_T c5_fcutoff;
  real_T c5_nargout = 2.0;
  real_T c5_nargin = 4.0;
  real_T c5_ubeta;
  real_T c5_ualpha;
  real_T c5_thetaCom;
  real_T c5_theta;
  real_T c5_A;
  real_T c5_B;
  real_T c5_x;
  real_T c5_y;
  real_T c5_b_x;
  real_T c5_b_y;
  real_T c5_c_x;
  real_T c5_c_y;
  real_T c5_d_x;
  real_T c5_e_x;
  real_T c5_b_A;
  real_T c5_b_B;
  real_T c5_f_x;
  real_T c5_d_y;
  real_T c5_g_x;
  real_T c5_e_y;
  real_T c5_h_x;
  real_T c5_f_y;
  real_T c5_i_x;
  real_T c5_j_x;
  real_T c5_k_x;
  real_T c5_c_A;
  real_T c5_c_B;
  real_T c5_l_x;
  real_T c5_g_y;
  real_T c5_m_x;
  real_T c5_h_y;
  real_T c5_n_x;
  real_T c5_i_y;
  real_T c5_o_x;
  real_T c5_p_x;
  real_T c5_q_x;
  real_T c5_d_A;
  real_T c5_d_B;
  real_T c5_r_x;
  real_T c5_j_y;
  real_T c5_s_x;
  real_T c5_k_y;
  real_T c5_t_x;
  real_T c5_l_y;
  real_T c5_u_x;
  real_T c5_v_x;
  real_T c5_w_x;
  real_T c5_e_A;
  real_T c5_e_B;
  real_T c5_x_x;
  real_T c5_m_y;
  real_T c5_y_x;
  real_T c5_n_y;
  real_T c5_ab_x;
  real_T c5_o_y;
  real_T c5_bb_x;
  real_T c5_cb_x;
  real_T *c5_b_thetaCom;
  real_T *c5_b_theta;
  real_T *c5_b_fcutoff;
  real_T *c5_b_frun;
  real_T *c5_b_be;
  real_T *c5_b_al;
  c5_b_frun = (real_T *)ssGetInputPortSignal(chartInstance.S, 2);
  c5_b_theta = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  c5_b_al = (real_T *)ssGetInputPortSignal(chartInstance.S, 0);
  c5_b_thetaCom = (real_T *)ssGetOutputPortSignal(chartInstance.S, 2);
  c5_b_be = (real_T *)ssGetInputPortSignal(chartInstance.S, 1);
  c5_b_fcutoff = (real_T *)ssGetInputPortSignal(chartInstance.S, 3);
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,4);
  c5_al = *c5_b_al;
  c5_be = *c5_b_be;
  c5_frun = *c5_b_frun;
  c5_fcutoff = *c5_b_fcutoff;
  sf_debug_symbol_scope_push(10U, 0U);
  sf_debug_symbol_scope_add("nargout", &c5_nargout, c5_sf_marshall);
  sf_debug_symbol_scope_add("nargin", &c5_nargin, c5_sf_marshall);
  sf_debug_symbol_scope_add("ubeta", &c5_ubeta, c5_sf_marshall);
  sf_debug_symbol_scope_add("ualpha", &c5_ualpha, c5_sf_marshall);
  sf_debug_symbol_scope_add("thetaCom", &c5_thetaCom, c5_sf_marshall);
  sf_debug_symbol_scope_add("theta", &c5_theta, c5_sf_marshall);
  sf_debug_symbol_scope_add("fcutoff", &c5_fcutoff, c5_sf_marshall);
  sf_debug_symbol_scope_add("frun", &c5_frun, c5_sf_marshall);
  sf_debug_symbol_scope_add("be", &c5_be, c5_sf_marshall);
  sf_debug_symbol_scope_add("al", &c5_al, c5_sf_marshall);
  CV_EML_FCN(0, 0);
/* ====