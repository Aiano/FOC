/* Include files */

#include "blascompat32.h"
#include "conver_PMSM_guangzhou_smo_sfun.h"
#include "c7_conver_PMSM_guangzhou_smo.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance.chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance.instanceNumber)
#include "conver_PMSM_guangzhou_smo_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */
#define c7_IN_NO_ACTIVE_CHILD          (0)

/* Variable Declarations */

/* Variable Definitions */
static SFc7_conver_PMSM_guangzhou_smoInstanceStruct chartInstance;

/* Function Declarations */
static void initialize_c7_conver_PMSM_guangzhou_smo(void);
static void initialize_params_c7_conver_PMSM_guangzhou_smo(void);
static void enable_c7_conver_PMSM_guangzhou_smo(void);
static void disable_c7_conver_PMSM_guangzhou_smo(void);
static void c7_update_debugger_state_c7_conver_PMSM_guangzhou_smo(void);
static const mxArray *get_sim_state_c7_conver_PMSM_guangzhou_smo(void);
static void set_sim_state_c7_conver_PMSM_guangzhou_smo(const mxArray *c7_st);
static void finalize_c7_conver_PMSM_guangzhou_smo(void);
static void sf_c7_conver_PMSM_guangzhou_smo(void);
static void init_script_number_translation(uint32_T c7_machineNumber, uint32_T
  c7_chartNumber);
static void c7_eml_warning(void);
static const mxArray *c7_sf_marshall(void *c7_chartInstance, void *c7_u);
static void c7_info_helper(c7_ResolvedFunctionInfo c7_info[21]);
static const mxArray *c7_emlrt_marshallOut(uint8_T c7_u);
static real_T c7_emlrt_marshallIn(const mxArray *c7_speed, char *c7_name);
static uint8_T c7_b_emlrt_marshallIn(const mxArray
  *c7_b_is_active_c7_conver_PMSM_guangzhou_smo, char *c7_name);
static void init_io_bus_offset(void);
static void init_dsm_address_info(void);

/* Function Definitions */
static void initialize_c7_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
  chartInstance.c7_is_active_c7_conver_PMSM_guangzhou_smo = 0U;
}

static void initialize_params_c7_conver_PMSM_guangzhou_smo(void)
{
}

static void enable_c7_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
}

static void disable_c7_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
}

static void c7_update_debugger_state_c7_conver_PMSM_guangzhou_smo(void)
{
}

static const mxArray *get_sim_state_c7_conver_PMSM_guangzhou_smo(void)
{
  const mxArray *c7_st = NULL;
  const mxArray *c7_y = NULL;
  real_T c7_u;
  const mxArray *c7_b_y = NULL;
  real_T *c7_speed;
  c7_speed = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  c7_st = NULL;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_createcellarray(2));
  c7_u = *c7_speed;
  c7_b_y = NULL;
  sf_mex_assign(&c7_b_y, sf_mex_create("y", &c7_u, 0, 0U, 0U, 0U, 0));
  sf_mex_setcell(c7_y, 0, c7_b_y);
  sf_mex_setcell(c7_y, 1, c7_emlrt_marshallOut
                 (chartInstance.c7_is_active_c7_conver_PMSM_guangzhou_smo));
  sf_mex_assign(&c7_st, c7_y);
  return c7_st;
}

static void set_sim_state_c7_conver_PMSM_guangzhou_smo(const mxArray *c7_st)
{
  const mxArray *c7_u;
  real_T *c7_speed;
  c7_speed = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  chartInstance.c7_doneDoubleBufferReInit = true;
  c7_u = sf_mex_dup(c7_st);
  *c7_speed = c7_emlrt_marshallIn(sf_mex_dup(sf_mex_getcell(c7_u, 0)), "speed");
  chartInstance.c7_is_active_c7_conver_PMSM_guangzhou_smo =
    c7_b_emlrt_marshallIn(sf_mex_dup(sf_mex_getcell(c7_u, 1)),
    "is_active_c7_conver_PMSM_guangzhou_smo");
  sf_mex_destroy(&c7_u);
  c7_update_debugger_state_c7_conver_PMSM_guangzhou_smo();
  sf_mex_destroy(&c7_st);
}

static void finalize_c7_conver_PMSM_guangzhou_smo(void)
{
}

static void sf_c7_conver_PMSM_guangzhou_smo(void)
{
  uint8_T c7_previousEvent;
  real_T c7_Theta;
  real_T c7_oldTheta;
  real_T c7_Ts;
  real_T c7_nargout = 1.0;
  real_T c7_nargin = 3.0;
  real_T c7_speed;
  real_T c7_A;
  real_T c7_B;
  real_T c7_x;
  real_T c7_y;
  real_T c7_b_x;
  real_T c7_b_y;
  real_T c7_c_x;
  real_T c7_c_y;
  real_T c7_b_A;
  real_T c7_b_B;
  real_T c7_d_x;
  real_T c7_d_y;
  real_T c7_e_x;
  real_T c7_e_y;
  real_T c7_f_x;
  real_T c7_f_y;
  real_T *c7_b_Theta;
  real_T *c7_b_speed;
  real_T *c7_b_oldTheta;
  real_T *c7_b_Ts;
  c7_b_Theta = (real_T *)ssGetInputPortSignal(chartInstance.S, 0);
  c7_b_speed = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  c7_b_oldTheta = (real_T *)ssGetInputPortSignal(chartInstance.S, 1);
  c7_b_Ts = (real_T *)ssGetInputPortSignal(chartInstance.S, 2);
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,6);
  _SFD_DATA_RANGE_CHECK(*c7_b_Theta, 0U);
  _SFD_DATA_RANGE_CHECK(*c7_b_speed, 1U);
  _SFD_DATA_RANGE_CHECK(*c7_b_oldTheta, 2U);
  _SFD_DATA_RANGE_CHECK(*c7_b_Ts, 3U);
  c7_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,6);
  c7_Theta = *c7_b_Theta;
  c7_oldTheta = *c7_b_oldTheta;
  c7_Ts = *c7_b_Ts;
  sf_debug_symbol_scope_push(6U, 0U);
  sf_debug_symbol_scope_add("nargout", &c7_nargout, c7_sf_marshall);
  sf_debug_symbol_scope_add("nargin", &c7_nargin, c7_sf_marshall);
  sf_debug_symbol_scope_add("speed", &c7_speed, c7_sf_marshall);
  sf_debug_symbol_scope_add("Ts", &c7_Ts, c7_sf_marshall);
  sf_debug_symbol_scope_add("oldTheta", &c7_oldTheta, c7_sf_marshall);
  sf_debug_symbol_scope_add("Theta", &c7_Theta, c7_sf_marshall);
  CV_EML_FCN(0, 0);
  _SFD_EML_CALL(0,2);
  if (CV_EML_IF(0, 0, c7_Theta - c7_oldTheta >= 0.0)) {
    _SFD_EML_CALL(0,3);
    c7_A = c7_Theta - c7_oldTheta;
    c7_B = c7_Ts;
    c7_x = c7_A;
    c7_y = c7_B;
    if (c7_y == 0.0) {
      c7_eml_warning();
    }

    c7_b_x = c7_x;
    c7_b_y = c7_y;
    c7_c_x = c7_b_x;
    c7_c_y = c7_b_y;
    c7_speed = c7_c_x / c7_c_y;
  } else {
    _SFD_EML_CALL(0,5);
    c7_b_A = (6.2831853071795862E+000 + c7_Theta) - c7_oldTheta;
    c7_b_B = c7_Ts;
    c7_d_x = c7_b_A;
    c7_d_y = c7_b_B;
    if (c7_d_y == 0.0) {
      c7_eml_warning();
    }

    c7_e_x = c7_d_x;
    c7_e_y = c7_d_y;
    c7_f_x = c7_e_x;
    c7_f_y = c7_e_y;
    c7_speed = c7_f_x / c7_f_y;
  }

  _SFD_EML_CALL(0,7);
  if (CV_EML_IF(0, 1, c7_speed > 1000.0)) {
    _SFD_EML_CALL(0,8);
    c7_speed = 1000.0;
  } else {
    _SFD_EML_CALL(0,10);
  }

  _SFD_EML_CALL(0,-10);
  sf_debug_symbol_scope_pop();
  *c7_b_speed = c7_speed;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,6);
  _sfEvent_ = c7_previousEvent;
  sf_debug_check_for_state_inconsistency
    (_conver_PMSM_guangzhou_smoMachineNumber_, chartInstance.chartNumber,
     chartInstance.
     instanceNumber);
}

static void init_script_number_translation(uint32_T c7_machineNumber, uint32_T
  c7_chartNumber)
{
}

static void c7_eml_warning(void)
{
  int32_T c7_i0;
  static char_T c7_cv0[15] = { 'D', 'i', 'v', 'i', 'd', 'e', ' ', 'b', 'y', ' ',
    'z', 'e', 'r', 'o', '.' };

  char_T c7_u[15];
  const mxArray *c7_y = NULL;
  int32_T c7_i1;
  static char_T c7_cv1[19] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'd', 'i', 'v',
    'i', 'd', 'e', 'B', 'y', 'Z', 'e', 'r', 'o' };

  char_T c7_b_u[19];
  const mxArray *c7_b_y = NULL;
  for (c7_i0 = 0; c7_i0 < 15; c7_i0 = c7_i0 + 1) {
    c7_u[c7_i0] = c7_cv0[c7_i0];
  }

  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", &c7_u, 10, 0U, 1U, 0U, 2, 1, 15));
  for (c7_i1 = 0; c7_i1 < 19; c7_i1 = c7_i1 + 1) {
    c7_b_u[c7_i1] = c7_cv1[c7_i1];
  }

  c7_b_y = NULL;
  sf_mex_assign(&c7_b_y, sf_mex_create("y", &c7_b_u, 10, 0U, 1U, 0U, 2, 1, 19));
  sf_mex_call_debug("warning", 0U, 2U, 14, c7_b_y, 14, c7_y);
}

static const mxArray *c7_sf_marshall(void *c7_chartInstance, void *c7_u)
{
  const mxArray *c7_y = NULL;
  real_T c7_b_u;
  const mxArray *c7_b_y = NULL;
  c7_y = NULL;
  c7_b_u = *((real_T *)c7_u);
  c7_b_y = NULL;
  sf_mex_assign(&c7_b_y, sf_mex_create("y", &c7_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c7_y, c7_b_y);
  return c7_y;
}

const mxArray *sf_c7_conver_PMSM_guangzhou_smo_get_eml_resolved_functions_info
  (void)
{
  const mxArray *c7_nameCaptureInfo = NULL;
  c7_ResolvedFunctionInfo c7_info[21];
  const mxArray *c7_m0 = NULL;
  int32_T c7_i2;
  c7_ResolvedFunctionInfo *c7_r0;
  c7_nameCaptureInfo = NULL;
  c7_info_helper(c7_info);
  sf_mex_assign(&c7_m0, sf_mex_createstruct("nameCaptureInfo", 1, 21));
  for (c7_i2 = 0; c7_i2 < 21; c7_i2 = c7_i2 + 1) {
    c7_r0 = &c7_info[c7_i2];
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", c7_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c7_r0->context)), "context",
                    "nameCaptureInfo", c7_i2);
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", c7_r0->name, 15, 0U,
      0U, 0U, 2, 1, strlen(c7_r0->name)), "name",
                    "nameCaptureInfo", c7_i2);
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", c7_r0->dominantType,
      15, 0U, 0U, 0U, 2, 1, strlen(c7_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c7_i2);
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", c7_r0->resolved, 15,
      0U, 0U, 0U, 2, 1, strlen(c7_r0->resolved)), "resolved"
                    , "nameCaptureInfo", c7_i2);
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", &c7_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c7_i2);
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", &c7_r0->fileTime1, 7,
      0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo", c7_i2);
    sf_mex_addfield(c7_m0, sf_mex_create("nameCaptureInfo", &c7_r0->fileTime2, 7,
      0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo", c7_i2);
  }

  sf_mex_assign(&c7_nameCaptureInfo, c7_m0);
  return c7_nameCaptureInfo;
}

static void c7_info_helper(c7_ResolvedFunctionInfo c7_info[21])
{
  c7_info[0].context = "";
  c7_info[0].name = "minus";
  c7_info[0].dominantType = "double";
  c7_info[0].resolved = "[B]minus";
  c7_info[0].fileLength = 0U;
  c7_info[0].fileTime1 = 0U;
  c7_info[0].fileTime2 = 0U;
  c7_info[1].context = "";
  c7_info[1].name = "ge";
  c7_info[1].dominantType = "double";
  c7_info[1].resolved = "[B]ge";
  c7_info[1].fileLength = 0U;
  c7_info[1].fileTime1 = 0U;
  c7_info[1].fileTime2 = 0U;
  c7_info[2].context = "";
  c7_info[2].name = "mrdivide";
  c7_info[2].dominantType = "double";
  c7_info[2].resolved = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c7_info[2].fileLength = 771U;
  c7_info[2].fileTime1 = 1219731336U;
  c7_info[2].fileTime2 = 0U;
  c7_info[3].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c7_info[3].name = "nargin";
  c7_info[3].dominantType = "";
  c7_info[3].resolved = "[B]nargin";
  c7_info[3].fileLength = 0U;
  c7_info[3].fileTime1 = 0U;
  c7_info[3].fileTime2 = 0U;
  c7_info[4].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c7_info[4].name = "isscalar";
  c7_info[4].dominantType = "double";
  c7_info[4].resolved = "[B]isscalar";
  c7_info[4].fileLength = 0U;
  c7_info[4].fileTime1 = 0U;
  c7_info[4].fileTime2 = 0U;
  c7_info[5].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c7_info[5].name = "rdivide";
  c7_info[5].dominantType = "double";
  c7_info[5].resolved = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c7_info[5].fileLength = 620U;
  c7_info[5].fileTime1 = 1213905166U;
  c7_info[5].fileTime2 = 0U;
  c7_info[6].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c7_info[6].name = "gt";
  c7_info[6].dominantType = "double";
  c7_info[6].resolved = "[B]gt";
  c7_info[6].fileLength = 0U;
  c7_info[6].fileTime1 = 0U;
  c7_info[6].fileTime2 = 0U;
  c7_info[7].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c7_info[7].name = "isa";
  c7_info[7].dominantType = "double";
  c7_info[7].resolved = "[B]isa";
  c7_info[7].fileLength = 0U;
  c7_info[7].fileTime1 = 0U;
  c7_info[7].fileTime2 = 0U;
  c7_info[8].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c7_info[8].name = "isempty";
  c7_info[8].dominantType = "double";
  c7_info[8].resolved = "[B]isempty";
  c7_info[8].fileLength = 0U;
  c7_info[8].fileTime1 = 0U;
  c7_info[8].fileTime2 = 0U;
  c7_info[9].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c7_info[9].name = "not";
  c7_info[9].dominantType = "logical";
  c7_info[9].resolved = "[B]not";
  c7_info[9].fileLength = 0U;
  c7_info[9].fileTime1 = 0U;
  c7_info[9].fileTime2 = 0U;
  c7_info[10].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c7_info[10].name = "strcmp";
  c7_info[10].dominantType = "char";
  c7_info[10].resolved = "[B]strcmp";
  c7_info[10].fileLength = 0U;
  c7_info[10].fileTime1 = 0U;
  c7_info[10].fileTime2 = 0U;
  c7_info[11].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c7_info[11].name = "eq";
  c7_info[11].dominantType = "double";
  c7_info[11].resolved = "[B]eq";
  c7_info[11].fileLength = 0U;
  c7_info[11].fileTime1 = 0U;
  c7_info[11].fileTime2 = 0U;
  c7_info[12].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c7_info[12].name = "eml_warning";
  c7_info[12].dominantType = "char";
  c7_info[12].resolved =
    "[I]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_warning.m";
  c7_info[12].fileLength = 274U;
  c7_info[12].fileTime1 = 1227588196U;
  c7_info[12].fileTime2 = 0U;
  c7_info[13].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c7_info[13].name = "eml_div";
  c7_info[13].dominantType = "double";
  c7_info[13].resolved = "[I]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m";
  c7_info[13].fileLength = 4269U;
  c7_info[13].fileTime1 = 1227588186U;
  c7_info[13].fileTime2 = 0U;
  c7_info[14].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m";
  c7_info[14].name = "isinteger";
  c7_info[14].dominantType = "double";
  c7_info[14].resolved = "[B]isinteger";
  c7_info[14].fileLength = 0U;
  c7_info[14].fileTime1 = 0U;
  c7_info[14].fileTime2 = 0U;
  c7_info[15].context =
    "[I]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m/eml_fldiv";
  c7_info[15].name = "isreal";
  c7_info[15].dominantType = "double";
  c7_info[15].resolved = "[B]isreal";
  c7_info[15].fileLength = 0U;
  c7_info[15].fileTime1 = 0U;
  c7_info[15].fileTime2 = 0U;
  c7_info[16].context = "";
  c7_info[16].name = "pi";
  c7_info[16].dominantType = "";
  c7_info[16].resolved = "[B]pi";
  c7_info[16].fileLength = 0U;
  c7_info[16].fileTime1 = 0U;
  c7_info[16].fileTime2 = 0U;
  c7_info[17].context = "";
  c7_info[17].name = "mtimes";
  c7_info[17].dominantType = "double";
  c7_info[17].resolved = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c7_info[17].fileLength = 2408U;
  c7_info[17].fileTime1 = 1227588202U;
  c7_info[17].fileTime2 = 0U;
  c7_info[18].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c7_info[18].name = "size";
  c7_info[18].dominantType = "double";
  c7_info[18].resolved = "[B]size";
  c7_info[18].fileLength = 0U;
  c7_info[18].fileTime1 = 0U;
  c7_info[18].fileTime2 = 0U;
  c7_info[19].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c7_info[19].name = "class";
  c7_info[19].dominantType = "double";
  c7_info[19].resolved = "[B]class";
  c7_info[19].fileLength = 0U;
  c7_info[19].fileTime1 = 0U;
  c7_info[19].fileTime2 = 0U;
  c7_info[20].context = "";
  c7_info[20].name = "plus";
  c7_info[20].dominantType = "double";
  c7_info[20].resolved = "[B]plus";
  c7_info[20].fileLength = 0U;
  c7_info[20].fileTime1 = 0U;
  c7_info[20].fileTime2 = 0U;
}

static const mxArray *c7_emlrt_marshallOut(uint8_T c7_u)
{
  const mxArray *c7_y = NULL;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", &c7_u, 3, 0U, 0U, 0U, 0));
  return c7_y;
}

static real_T c7_emlrt_marshallIn(const mxArray *c7_speed, char *c7_name)
{
  real_T c7_y;
  real_T c7_d0;
  sf_mex_import(c7_name, sf_mex_dup(c7_speed), &c7_d0, 1, 0, 0U, 0, 0U, 0);
  c7_y = c7_d0;
  sf_mex_destroy(&c7_speed);
  return c7_y;
}

static uint8_T c7_b_emlrt_marshallIn(const mxArray
  *c7_b_is_active_c7_conver_PMSM_guangzhou_smo, char *c7_name)
{
  uint8_T c7_y;
  uint8_T c7_u0;
  sf_mex_import(c7_name, sf_mex_dup(c7_b_is_active_c7_conver_PMSM_guangzhou_smo),
                &c7_u0, 1, 3, 0U, 0, 0U, 0);
  c7_y = c7_u0;
  sf_mex_destroy(&c7_b_is_active_c7_conver_PMSM_guangzhou_smo);
  return c7_y;
}

static void init_io_bus_offset(void)
{
}

static void init_dsm_address_info(void)
{
}

/* SFunction Glue Code */
void sf_c7_conver_PMSM_guangzhou_smo_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3739830333U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(743688406U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3396269471U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(813894450U);
}

mxArray *sf_c7_conver_PMSM_guangzhou_smo_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(2957002512U);
    pr[1] = (double)(495065189U);
    pr[2] = (double)(2127829812U);
    pr[3] = (double)(2452550373U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,3,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c7_conver_PMSM_guangzhou_smo(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  char *infoEncStr[] = {
    "100 S1x2'type','srcId','name','auxInfo'{{M[1],M[5],T\"speed\",},{M[8],M[0],T\"is_active_c7_conver_PMSM_guangzhou_smo\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c7_conver_PMSM_guangzhou_smo_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_conver_PMSM_guangzhou_smoMachineNumber_,
           7,
           1,
           1,
           4,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance.chartNumber),
           &(chartInstance.instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation
            (_conver_PMSM_guangzhou_smoMachineNumber_,chartInstance.chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_conver_PMSM_guangzhou_smoMachineNumber_,chartInstance.chartNumber,
             1);
          sf_debug_set_chart_event_thresholds
            (_conver_PMSM_guangzhou_smoMachineNumber_,
             chartInstance.chartNumber,
             0,
             0,
             0);
          _SFD_SET_DATA_PROPS(0,1,1,0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"Theta",0,
                              c7_sf_marshall);
          _SFD_SET_DATA_PROPS(1,2,0,1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"speed",0,
                              NULL);
          _SFD_SET_DATA_PROPS(2,1,1,0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,
                              "oldTheta",0,NULL);
          _SFD_SET_DATA_PROPS(3,1,1,0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"Ts",0,
                              NULL);
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,1,2,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,224);
        _SFD_CV_INIT_EML_IF(0,0,42,64,106,159);
        _SFD_CV_INIT_EML_IF(0,1,160,175,192,218);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          real_T *c7_Theta;
          real_T *c7_speed;
          real_T *c7_oldTheta;
          real_T *c7_Ts;
          c7_Theta = (real_T *)ssGetInputPortSignal(chartInstance.S, 0);
          c7_speed = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
          c7_oldTheta = (real_T *)ssGetInputPortSignal(chartInstance.S, 1);
          c7_Ts = (real_T *)ssGetInputPortSignal(chartInstance.S, 2);
          _SFD_SET_DATA_VALUE_PTR(0U, c7_Theta);
          _SFD_SET_DATA_VALUE_PTR(1U, c7_speed);
          _SFD_SET_DATA_VALUE_PTR(2U, c7_oldTheta);
          _SFD_SET_DATA_VALUE_PTR(3U, c7_Ts);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration
        (_conver_PMSM_guangzhou_smoMachineNumber_,chartInstance.chartNumber,
         chartInstance.instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c7_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  chart_debug_initialization(chartInstance.S,0);
  initialize_params_c7_conver_PMSM_guangzhou_smo();
  initialize_c7_conver_PMSM_guangzhou_smo();
}

static void sf_opaque_enable_c7_conver_PMSM_guangzhou_smo(void *chartInstanceVar)
{
  enable_c7_conver_PMSM_guangzhou_smo();
}

static void sf_opaque_disable_c7_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  disable_c7_conver_PMSM_guangzhou_smo();
}

static void sf_opaque_gateway_c7_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  sf_c7_conver_PMSM_guangzhou_smo();
}

static mxArray* sf_opaque_get_sim_state_c7_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  mxArray *st = (mxArray *) get_sim_state_c7_conver_PMSM_guangzhou_smo();
  return st;
}

static void sf_opaque_set_sim_state_c7_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar, const mxArray *st)
{
  set_sim_state_c7_conver_PMSM_guangzhou_smo(sf_mex_dup(st));
}

static void sf_opaque_terminate_c7_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  if (sim_mode_is_rtw_gen(chartInstance.S) || sim_mode_is_external
      (chartInstance.S)) {
    sf_clear_rtw_identifier(chartInstance.S);
  }

  finalize_c7_conver_PMSM_guangzhou_smo();
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c7_conver_PMSM_guangzhou_smo(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c7_conver_PMSM_guangzhou_smo();
  }
}

static void mdlSetWorkWidths_c7_conver_PMSM_guangzhou_smo(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("conver_PMSM_guangzhou_smo",
      "conver_PMSM_guangzhou_smo",7);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("conver_PMSM_guangzhou_smo",
                "conver_PMSM_guangzhou_smo",7,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop(
      "conver_PMSM_guangzhou_smo","conver_PMSM_guangzhou_smo",7,
      "gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"conver_PMSM_guangzhou_smo",
        "conver_PMSM_guangzhou_smo",7,3);
      sf_mark_chart_reusable_outputs(S,"conver_PMSM_guangzhou_smo",
        "conver_PMSM_guangzhou_smo",7,1);
    }

    sf_set_rtw_dwork_info(S,"conver_PMSM_guangzhou_smo",
                          "conver_PMSM_guangzhou_smo",7);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(2401380537U));
  ssSetChecksum1(S,(2810998880U));
  ssSetChecksum2(S,(3358170562U));
  ssSetChecksum3(S,(200755423U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c7_conver_PMSM_guangzhou_smo(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "conver_PMSM_guangzhou_smo",
      "conver_PMSM_guangzhou_smo",7);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c7_conver_PMSM_guangzhou_smo(SimStruct *S)
{
  chartInstance.chartInfo.chartInstance = NULL;
  chartInstance.chartInfo.isEMLChart = 1;
  chartInstance.chartInfo.chartInitialized = 0;
  chartInstance.chartInfo.sFunctionGateway =
    sf_opaque_gateway_c7_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.initializeChart =
    sf_opaque_initialize_c7_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.terminateChart =
    sf_opaque_terminate_c7_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.enableChart =
    sf_opaque_enable_c7_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.disableChart =
    sf_opaque_disable_c7_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.getSimState =
    sf_opaque_get_sim_state_c7_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.setSimState =
    sf_opaque_set_sim_state_c7_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c7_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.zeroCrossings = NULL;
  chartInstance.chartInfo.outputs = NULL;
  chartInstance.chartInfo.derivatives = NULL;
  chartInstance.chartInfo.mdlRTW = mdlRTW_c7_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.mdlStart = mdlStart_c7_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c7_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.extModeExec = NULL;
  chartInstance.chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance.chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance.chartInfo.storeCurrentConfiguration = NULL;
  chartInstance.S = S;
  ssSetUserData(S,(void *)(&(chartInstance.chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info();
  }

  chart_debug_initialization(S,1);
}

void c7_conver_PMSM_guangzhou_smo_method_dispatcher(SimStruct *S, int_T method,
  void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c7_conver_PMSM_guangzhou_smo(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c7_conver_PMSM_guangzhou_smo(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c7_conver_PMSM_guangzhou_smo(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c7_conver_PMSM_guangzhou_smo_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
