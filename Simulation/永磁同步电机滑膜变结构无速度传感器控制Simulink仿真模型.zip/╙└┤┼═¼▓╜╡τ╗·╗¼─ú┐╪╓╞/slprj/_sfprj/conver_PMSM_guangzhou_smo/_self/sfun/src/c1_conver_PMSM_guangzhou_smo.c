/* Include files */

#include "blascompat32.h"
#include "conver_PMSM_guangzhou_smo_sfun.h"
#include "c1_conver_PMSM_guangzhou_smo.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance.chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance.instanceNumber)
#include "conver_PMSM_guangzhou_smo_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */
#define c1_IN_NO_ACTIVE_CHILD          (0)

/* Variable Declarations */

/* Variable Definitions */
static SFc1_conver_PMSM_guangzhou_smoInstanceStruct chartInstance;

/* Function Declarations */
static void initialize_c1_conver_PMSM_guangzhou_smo(void);
static void initialize_params_c1_conver_PMSM_guangzhou_smo(void);
static void enable_c1_conver_PMSM_guangzhou_smo(void);
static void disable_c1_conver_PMSM_guangzhou_smo(void);
static void c1_update_debugger_state_c1_conver_PMSM_guangzhou_smo(void);
static const mxArray *get_sim_state_c1_conver_PMSM_guangzhou_smo(void);
static void set_sim_state_c1_conver_PMSM_guangzhou_smo(const mxArray *c1_st);
static void finalize_c1_conver_PMSM_guangzhou_smo(void);
static void sf_c1_conver_PMSM_guangzhou_smo(void);
static void c1_c1_conver_PMSM_guangzhou_smo(void);
static void init_script_number_translation(uint32_T c1_machineNumber, uint32_T
  c1_chartNumber);
static void c1_eml_warning(void);
static const mxArray *c1_sf_marshall(void *c1_chartInstance, void *c1_u);
static const mxArray *c1_b_sf_marshall(void *c1_chartInstance, void *c1_u);
static void c1_info_helper(c1_ResolvedFunctionInfo c1_info[25]);
static const mxArray *c1_emlrt_marshallOut(uint8_T c1_u);
static real_T c1_emlrt_marshallIn(const mxArray *c1_c1, char *c1_name);
static real_T c1_b_emlrt_marshallIn(const mxArray *c1_c2, char *c1_name);
static real_T c1_c_emlrt_marshallIn(const mxArray *c1_c3, char *c1_name);
static uint8_T c1_d_emlrt_marshallIn(const mxArray
  *c1_b_is_active_c1_conver_PMSM_guangzhou_smo, char *c1_name);
static void init_io_bus_offset(void);
static void init_dsm_address_info(void);

/* Function Definitions */
static void initialize_c1_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
  chartInstance.c1_is_active_c1_conver_PMSM_guangzhou_smo = 0U;
}

static void initialize_params_c1_conver_PMSM_guangzhou_smo(void)
{
}

static void enable_c1_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
}

static void disable_c1_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
}

static void c1_update_debugger_state_c1_conver_PMSM_guangzhou_smo(void)
{
}

static const mxArray *get_sim_state_c1_conver_PMSM_guangzhou_smo(void)
{
  const mxArray *c1_st = NULL;
  const mxArray *c1_y = NULL;
  real_T c1_u;
  const mxArray *c1_b_y = NULL;
  real_T c1_b_u;
  const mxArray *c1_c_y = NULL;
  real_T c1_c_u;
  const mxArray *c1_d_y = NULL;
  real_T *c1_c1;
  real_T *c1_c2;
  real_T *c1_c3;
  c1_c3 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 3);
  c1_c1 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  c1_c2 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 2);
  c1_st = NULL;
  c1_y = NULL;
  sf_mex_assign(&c1_y, sf_mex_createcellarray(4));
  c1_u = *c1_c1;
  c1_b_y = NULL;
  sf_mex_assign(&c1_b_y, sf_mex_create("y", &c1_u, 0, 0U, 0U, 0U, 0));
  sf_mex_setcell(c1_y, 0, c1_b_y);
  c1_b_u = *c1_c2;
  c1_c_y = NULL;
  sf_mex_assign(&c1_c_y, sf_mex_create("y", &c1_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_setcell(c1_y, 1, c1_c_y);
  c1_c_u = *c1_c3;
  c1_d_y = NULL;
  sf_mex_assign(&c1_d_y, sf_mex_create("y", &c1_c_u, 0, 0U, 0U, 0U, 0));
  sf_mex_setcell(c1_y, 2, c1_d_y);
  sf_mex_setcell(c1_y, 3, c1_emlrt_marshallOut
                 (chartInstance.c1_is_active_c1_conver_PMSM_guangzhou_smo));
  sf_mex_assign(&c1_st, c1_y);
  return c1_st;
}

static void set_sim_state_c1_conver_PMSM_guangzhou_smo(const mxArray *c1_st)
{
  const mxArray *c1_u;
  real_T *c1_c1;
  real_T *c1_c2;
  real_T *c1_c3;
  c1_c3 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 3);
  c1_c1 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  c1_c2 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 2);
  chartInstance.c1_doneDoubleBufferReInit = true;
  c1_u = sf_mex_dup(c1_st);
  *c1_c1 = c1_emlrt_marshallIn(sf_mex_dup(sf_mex_getcell(c1_u, 0)), "c1");
  *c1_c2 = c1_b_emlrt_marshallIn(sf_mex_dup(sf_mex_getcell(c1_u, 1)), "c2");
  *c1_c3 = c1_c_emlrt_marshallIn(sf_mex_dup(sf_mex_getcell(c1_u, 2)), "c3");
  chartInstance.c1_is_active_c1_conver_PMSM_guangzhou_smo =
    c1_d_emlrt_marshallIn(sf_mex_dup(sf_mex_getcell(c1_u, 3)),
    "is_active_c1_conver_PMSM_guangzhou_smo");
  sf_mex_destroy(&c1_u);
  c1_update_debugger_state_c1_conver_PMSM_guangzhou_smo();
  sf_mex_destroy(&c1_st);
}

static void finalize_c1_conver_PMSM_guangzhou_smo(void)
{
}

static void sf_c1_conver_PMSM_guangzhou_smo(void)
{
  int32_T c1_i0;
  uint8_T c1_previousEvent;
  real_T *c1_c1;
  real_T *c1_Ts;
  real_T *c1_Ud;
  real_T *c1_c2;
  real_T *c1_c3;
  real_T (*c1_u)[2];
  c1_Ts = (real_T *)ssGetInputPortSignal(chartInstance.S, 1);
  c1_c3 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 3);
  c1_c1 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  c1_c2 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 2);
  c1_u = (real_T (*)[2])ssGetInputPortSignal(chartInstance.S, 0);
  c1_Ud = (real_T *)ssGetInputPortSignal(chartInstance.S, 2);
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,0);
  for (c1_i0 = 0; c1_i0 < 2; c1_i0 = c1_i0 + 1) {
    _SFD_DATA_RANGE_CHECK((*c1_u)[c1_i0], 0U);
  }

  _SFD_DATA_RANGE_CHECK(*c1_c1, 1U);
  _SFD_DATA_RANGE_CHECK(*c1_Ts, 2U);
  _SFD_DATA_RANGE_CHECK(*c1_Ud, 3U);
  _SFD_DATA_RANGE_CHECK(*c1_c2, 4U);
  _SFD_DATA_RANGE_CHECK(*c1_c3, 5U);
  c1_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  c1_c1_conver_PMSM_guangzhou_smo();
  _sfEvent_ = c1_previousEvent;
  sf_debug_check_for_state_inconsistency
    (_conver_PMSM_guangzhou_smoMachineNumber_, chartInstance.chartNumber,
     chartInstance.
     instanceNumber);
}

static void c1_c1_conver_PMSM_guangzhou_smo(void)
{
  int32_T c1_i1;
  real_T c1_u[2];
  real_T c1_Ts;
  real_T c1_Ud;
  real_T c1_nargout = 3.0;
  real_T c1_nargin = 3.0;
  real_T c1_Tc;
  real_T c1_Tb;
  real_T c1_Ta;
  real_T c1_T2;
  real_T c1_T1;
  real_T c1_t2;
  real_T c1_t1;
  real_T c1_Z;
  real_T c1_Y;
  real_T c1_X;
  real_T c1_N;
  real_T c1_C;
  real_T c1_vc;
  real_T c1_B;
  real_T c1_vb;
  real_T c1_A;
  real_T c1_va;
  real_T c1_c3;
  real_T c1_c2;
  real_T c1_c1;
  real_T c1_b;
  real_T c1_y;
  real_T c1_b_A;
  real_T c1_x;
  real_T c1_b_x;
  real_T c1_c_x;
  real_T c1_b_b;
  real_T c1_b_y;
  real_T c1_c_A;
  real_T c1_d_x;
  real_T c1_e_x;
  real_T c1_f_x;
  real_T c1_c_b;
  real_T c1_c_y;
  real_T c1_d_b;
  real_T c1_d_y;
  real_T c1_e_b;
  real_T c1_a;
  real_T c1_f_b;
  real_T c1_d_A;
  real_T c1_b_B;
  real_T c1_g_x;
  real_T c1_e_y;
  real_T c1_h_x;
  real_T c1_f_y;
  real_T c1_i_x;
  real_T c1_g_y;
  real_T c1_g_b;
  real_T c1_h_y;
  real_T c1_h_b;
  real_T c1_i_y;
  real_T c1_b_a;
  real_T c1_i_b;
  real_T c1_e_A;
  real_T c1_j_x;
  real_T c1_k_x;
  real_T c1_l_x;
  real_T c1_f_A;
  real_T c1_c_B;
  real_T c1_m_x;
  real_T c1_j_y;
  real_T c1_n_x;
  real_T c1_k_y;
  real_T c1_o_x;
  real_T c1_l_y;
  real_T c1_j_b;
  real_T c1_m_y;
  real_T c1_k_b;
  real_T c1_n_y;
  real_T c1_c_a;
  real_T c1_l_b;
  real_T c1_g_A;
  real_T c1_p_x;
  real_T c1_q_x;
  real_T c1_r_x;
  real_T c1_h_A;
  real_T c1_d_B;
  real_T c1_s_x;
  real_T c1_o_y;
  real_T c1_t_x;
  real_T c1_p_y;
  real_T c1_u_x;
  real_T c1_q_y;
  real_T c1_d_a;
  real_T c1_m_b;
  real_T c1_i_A;
  real_T c1_e_B;
  real_T c1_v_x;
  real_T c1_r_y;
  real_T c1_w_x;
  real_T c1_s_y;
  real_T c1_x_x;
  real_T c1_t_y;
  real_T c1_e_a;
  real_T c1_n_b;
  real_T c1_j_A;
  real_T c1_f_B;
  real_T c1_y_x;
  real_T c1_u_y;
  real_T c1_ab_x;
  real_T c1_v_y;
  real_T c1_bb_x;
  real_T c1_w_y;
  real_T c1_k_A;
  real_T c1_cb_x;
  real_T c1_db_x;
  real_T c1_eb_x;
  real_T c1_l_A;
  real_T c1_fb_x;
  real_T c1_gb_x;
  real_T c1_hb_x;
  real_T c1_x_y;
  real_T c1_m_A;
  real_T c1_ib_x;
  real_T c1_jb_x;
  real_T c1_kb_x;
  real_T c1_y_y;
  real_T *c1_b_c3;
  real_T *c1_b_c2;
  real_T *c1_b_c1;
  real_T *c1_b_Ud;
  real_T *c1_b_Ts;
  real_T (*c1_b_u)[2];
  c1_b_Ts = (real_T *)ssGetInputPortSignal(chartInstance.S, 1);
  c1_b_c3 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 3);
  c1_b_c1 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  c1_b_c2 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 2);
  c1_b_u = (real_T (*)[2])ssGetInputPortSignal(chartInstance.S, 0);
  c1_b_Ud = (real_T *)ssGetInputPortSignal(chartInstance.S, 2);
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,0);
  for (c1_i1 = 0; c1_i1 < 2; c1_i1 = c1_i1 + 1) {
    c1_u[c1_i1] = (*c1_b_u)[c1_i1];
  }

  c1_Ts = *c1_b_Ts;
  c1_Ud = *c1_b_Ud;
  sf_debug_symbol_scope_push(25U, 0U);
  sf_debug_symbol_scope_add("nargout", &c1_nargout, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("nargin", &c1_nargin, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("Tc", &c1_Tc, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("Tb", &c1_Tb, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("Ta", &c1_Ta, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("T2", &c1_T2, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("T1", &c1_T1, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("t2", &c1_t2, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("t1", &c1_t1, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("Z", &c1_Z, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("Y", &c1_Y, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("X", &c1_X, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("N", &c1_N, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("C", &c1_C, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("vc", &c1_vc, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("B", &c1_B, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("vb", &c1_vb, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("A", &c1_A, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("va", &c1_va, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("c3", &c1_c3, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("c2", &c1_c2, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("c1", &c1_c1, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("Ud", &c1_Ud, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("Ts", &c1_Ts, c1_b_sf_marshall);
  sf_debug_symbol_scope_add("u", &c1_u, c1_sf_marshall);
  CV_EML_FCN(0, 0);
  _SFD_EML_CALL(0,2);
  c1_va = c1_u[1];
  _SFD_EML_CALL(0,3);
  if (CV_EML_IF(0, 0, c1_va > 0.0)) {
    _SFD_EML_CALL(0,4);
    c1_A = 1.0;
  } else {
    _SFD_EML_CALL(0,6);
    c1_A = 0.0;
  }

  _SFD_EML_CALL(0,8);
  c1_b = c1_u[0];
  c1_y = 1.7320508075688772E+000 * c1_b;
  c1_b_A = c1_y - c1_u[1];
  c1_x = c1_b_A;
  c1_b_x = c1_x;
  c1_c_x = c1_b_x;
  c1_vb = c1_c_x / 2.0;
  _SFD_EML_CALL(0,9);
  if (CV_EML_IF(0, 1, c1_vb > 0.0)) {
    _SFD_EML_CALL(0,10);
    c1_B = 1.0;
  } else {
    _SFD_EML_CALL(0,12);
    c1_B = 0.0;
  }

  _SFD_EML_CALL(0,14);
  c1_b_b = c1_u[0];
  c1_b_y = -1.7320508075688772E+000 * c1_b_b;
  c1_c_A = c1_b_y - c1_u[1];
  c1_d_x = c1_c_A;
  c1_e_x = c1_d_x;
  c1_f_x = c1_e_x;
  c1_vc = c1_f_x / 2.0;
  _SFD_EML_CALL(0,15);
  if (CV_EML_IF(0, 2, c1_vc > 0.0)) {
    _SFD_EML_CALL(0,16);
    c1_C = 1.0;
  } else {
    _SFD_EML_CALL(0,18);
    c1_C = 0.0;
  }

  _SFD_EML_CALL(0,20);
  c1_c_b = c1_C;
  c1_c_y = 4.0 * c1_c_b;
  c1_d_b = c1_B;
  c1_d_y = 2.0 * c1_d_b;
  c1_N = (c1_A + c1_d_y) + c1_c_y;
  _SFD_EML_CALL(0,21);
  c1_e_b = c1_u[1];
  c1_a = 1.7320508075688772E+000 * c1_e_b;
  c1_f_b = c1_Ts;
  c1_d_A = c1_a * c1_f_b;
  c1_b_B = c1_Ud;
  c1_g_x = c1_d_A;
  c1_e_y = c1_b_B;
  if (c1_e_y == 0.0) {
    c1_eml_warning();
  }

  c1_h_x = c1_g_x;
  c1_f_y = c1_e_y;
  c1_i_x = c1_h_x;
  c1_g_y = c1_f_y;
  c1_X = c1_i_x / c1_g_y;
  _SFD_EML_CALL(0,22);
  c1_g_b = c1_u[1];
  c1_h_y = 1.7320508075688772E+000 * c1_g_b;
  c1_h_b = c1_u[0];
  c1_i_y = 3.0 * c1_h_b;
  c1_b_a = c1_i_y + c1_h_y;
  c1_i_b = c1_Ts;
  c1_e_A = c1_b_a * c1_i_b;
  c1_j_x = c1_e_A;
  c1_k_x = c1_j_x;
  c1_l_x = c1_k_x;
  c1_f_A = c1_l_x / 2.0;
  c1_c_B = c1_Ud;
  c1_m_x = c1_f_A;
  c1_j_y = c1_c_B;
  if (c1_j_y == 0.0) {
    c1_eml_warning();
  }

  c1_n_x = c1_m_x;
  c1_k_y = c1_j_y;
  c1_o_x = c1_n_x;
  c1_l_y = c1_k_y;
  c1_Y = c1_o_x / c1_l_y;
  _SFD_EML_CALL(0,23);
  c1_j_b = c1_u[1];
  c1_m_y = 1.7320508075688772E+000 * c1_j_b;
  c1_k_b = c1_u[0];
  c1_n_y = -3.0 * c1_k_b;
  c1_c_a = c1_n_y + c1_m_y;
  c1_l_b = c1_Ts;
  c1_g_A = c1_c_a * c1_l_b;
  c1_p_x = c1_g_A;
  c1_q_x = c1_p_x;
  c1_r_x = c1_q_x;
  c1_h_A = c1_r_x / 2.0;
  c1_d_B = c1_Ud;
  c1_s_x = c1_h_A;
  c1_o_y = c1_d_B;
  if (c1_o_y == 0.0) {
    c1_eml_warning();
  }

  c1_t_x = c1_s_x;
  c1_p_y = c1_o_y;
  c1_u_x = c1_t_x;
  c1_q_y = c1_p_y;
  c1_Z = c1_u_x / c1_q_y;
  _SFD_EML_CALL(0,24);
  if (CV_EML_IF(0, 3, c1_N == 3.0)) {
    _SFD_EML_CALL(0,25);
    c1_t1 = -c1_Z;
    _SFD_EML_CALL(0,25);
    c1_t2 = c1_X;
  } else {
    _SFD_EML_CALL(0,26);
    if (CV_EML_IF(0, 4, c1_N == 1.0)) {
      _SFD_EML_CALL(0,27);
      c1_t1 = c1_Z;
      _SFD_EML_CALL(0,27);
      c1_t2 = c1_Y;
    } else {
      _SFD_EML_CALL(0,28);
      if (CV_EML_IF(0, 5, c1_N == 5.0)) {
        _SFD_EML_CALL(0,29);
        c1_t1 = c1_X;
        _SFD_EML_CALL(0,29);
        c1_t2 = -c1_Y;
      } else {
        _SFD_EML_CALL(0,30);
        if (CV_EML_IF(0, 6, c1_N == 4.0)) {
          _SFD_EML_CALL(0,31);
          c1_t1 = -c1_X;
          _SFD_EML_CALL(0,31);
          c1_t2 = c1_Z;
        } else {
          _SFD_EML_CALL(0,32);
          if (CV_EML_IF(0, 7, c1_N == 6.0)) {
            _SFD_EML_CALL(0,33);
            c1_t1 = -c1_Y;
            _SFD_EML_CALL(0,33);
            c1_t2 = -c1_Z;
          } else {
            _SFD_EML_CALL(0,35);
            c1_t1 = c1_Y;
            _SFD_EML_CALL(0,35);
            c1_t2 = -c1_X;
          }
        }
      }
    }
  }

  _SFD_EML_CALL(0,37);
  if (CV_EML_IF(0, 8, c1_t1 + c1_t2 > c1_Ts)) {
    _SFD_EML_CALL(0,38);
    c1_d_a = c1_t1;
    c1_m_b = c1_Ts;
    c1_i_A = c1_d_a * c1_m_b;
    c1_e_B = c1_t1 + c1_t2;
    c1_v_x = c1_i_A;
    c1_r_y = c1_e_B;
    if (c1_r_y == 0.0) {
      c1_eml_warning();
    }

    c1_w_x = c1_v_x;
    c1_s_y = c1_r_y;
    c1_x_x = c1_w_x;
    c1_t_y = c1_s_y;
    c1_T1 = c1_x_x / c1_t_y;
    _SFD_EML_CALL(0,39);
    c1_e_a = c1_t2;
    c1_n_b = c1_Ts;
    c1_j_A = c1_e_a * c1_n_b;
    c1_f_B = c1_t1 + c1_t2;
    c1_y_x = c1_j_A;
    c1_u_y = c1_f_B;
    if (c1_u_y == 0.0) {
      c1_eml_warning();
    }

    c1_ab_x = c1_y_x;
    c1_v_y = c1_u_y;
    c1_bb_x = c1_ab_x;
    c1_w_y = c1_v_y;
    c1_T2 = c1_bb_x / c1_w_y;
  } else {
    _SFD_EML_CALL(0,41);
    c1_T1 = c1_t1;
    _SFD_EML_CALL(0,42);
    c1_T2 = c1_t2;
  }

  _SFD_EML_CALL(0,44);
  c1_k_A = (c1_Ts - c1_T1) - c1_T2;
  c1_cb_x = c1_k_A;
  c1_db_x = c1_cb_x;
  c1_eb_x = c1_db_x;
  c1_Ta = c1_eb_x / 4.0;
  _SFD_EML_CALL(0,45);
  c1_l_A = c1_T1;
  c1_fb_x = c1_l_A;
  c1_gb_x = c1_fb_x;
  c1_hb_x = c1_gb_x;
  c1_x_y = c1_hb_x / 2.0;
  c1_Tb = c1_Ta + c1_x_y;
  _SFD_EML_CALL(0,46);
  c1_m_A = c1_T2;
  c1_ib_x = c1_m_A;
  c1_jb_x = c1_ib_x;
  c1_kb_x = c1_jb_x;
  c1_y_y = c1_kb_x / 2.0;
  c1_Tc = c1_Tb + c1_y_y;
  _SFD_EML_CALL(0,47);
  if (CV_EML_IF(0, 9, c1_N == 3.0)) {
    _SFD_EML_CALL(0,48);
    c1_c1 = c1_Ta;
    _SFD_EML_CALL(0,48);
    c1_c2 = c1_Tb;
    _SFD_EML_CALL(0,48);
    c1_c3 = c1_Tc;
  } else {
    _SFD_EML_CALL(0,49);
    if (CV_EML_IF(0, 10, c1_N == 1.0)) {
      _SFD_EML_CALL(0,50);
      c1_c1 = c1_Tb;
      _SFD_EML_CALL(0,50);
      c1_c2 = c1_Ta;
      _SFD_EML_CALL(0,50);
      c1_c3 = c1_Tc;
    } else {
      _SFD_EML_CALL(0,51);
      if (CV_EML_IF(0, 11, c1_N == 5.0)) {
        _SFD_EML_CALL(0,52);
        c1_c1 = c1_Tc;
        _SFD_EML_CALL(0,52);
        c1_c2 = c1_Ta;
        _SFD_EML_CALL(0,52);
        c1_c3 = c1_Tb;
      } else {
        _SFD_EML_CALL(0,53);
        if (CV_EML_IF(0, 12, c1_N == 4.0)) {
          _SFD_EML_CALL(0,54);
          c1_c1 = c1_Tc;
          _SFD_EML_CALL(0,54);
          c1_c2 = c1_Tb;
          _SFD_EML_CALL(0,54);
          c1_c3 = c1_Ta;
        } else {
          _SFD_EML_CALL(0,55);
          if (CV_EML_IF(0, 13, c1_N == 6.0)) {
            _SFD_EML_CALL(0,56);
            c1_c1 = c1_Tb;
            _SFD_EML_CALL(0,56);
            c1_c2 = c1_Tc;
            _SFD_EML_CALL(0,56);
            c1_c3 = c1_Ta;
          } else {
            _SFD_EML_CALL(0,58);
            c1_c1 = c1_Ta;
            _SFD_EML_CALL(0,58);
            c1_c2 = c1_Tc;
            _SFD_EML_CALL(0,58);
            c1_c3 = c1_Tb;
          }
        }
      }
    }
  }

  _SFD_EML_CALL(0,-58);
  sf_debug_symbol_scope_pop();
  *c1_b_c1 = c1_c1;
  *c1_b_c2 = c1_c2;
  *c1_b_c3 = c1_c3;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,0);
}

static void init_script_number_translation(uint32_T c1_machineNumber, uint32_T
  c1_chartNumber)
{
}

static void c1_eml_warning(void)
{
  int32_T c1_i2;
  static char_T c1_cv0[15] = { 'D', 'i', 'v', 'i', 'd', 'e', ' ', 'b', 'y', ' ',
    'z', 'e', 'r', 'o', '.' };

  char_T c1_u[15];
  const mxArray *c1_y = NULL;
  int32_T c1_i3;
  static char_T c1_cv1[19] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'd', 'i', 'v',
    'i', 'd', 'e', 'B', 'y', 'Z', 'e', 'r', 'o' };

  char_T c1_b_u[19];
  const mxArray *c1_b_y = NULL;
  for (c1_i2 = 0; c1_i2 < 15; c1_i2 = c1_i2 + 1) {
    c1_u[c1_i2] = c1_cv0[c1_i2];
  }

  c1_y = NULL;
  sf_mex_assign(&c1_y, sf_mex_create("y", &c1_u, 10, 0U, 1U, 0U, 2, 1, 15));
  for (c1_i3 = 0; c1_i3 < 19; c1_i3 = c1_i3 + 1) {
    c1_b_u[c1_i3] = c1_cv1[c1_i3];
  }

  c1_b_y = NULL;
  sf_mex_assign(&c1_b_y, sf_mex_create("y", &c1_b_u, 10, 0U, 1U, 0U, 2, 1, 19));
  sf_mex_call_debug("warning", 0U, 2U, 14, c1_b_y, 14, c1_y);
}

static const mxArray *c1_sf_marshall(void *c1_chartInstance, void *c1_u)
{
  const mxArray *c1_y = NULL;
  int32_T c1_i4;
  real_T c1_b_u[2];
  const mxArray *c1_b_y = NULL;
  c1_y = NULL;
  for (c1_i4 = 0; c1_i4 < 2; c1_i4 = c1_i4 + 1) {
    c1_b_u[c1_i4] = (*((real_T (*)[2])c1_u))[c1_i4];
  }

  c1_b_y = NULL;
  sf_mex_assign(&c1_b_y, sf_mex_create("y", &c1_b_u, 0, 0U, 1U, 0U, 1, 2));
  sf_mex_assign(&c1_y, c1_b_y);
  return c1_y;
}

static const mxArray *c1_b_sf_marshall(void *c1_chartInstance, void *c1_u)
{
  const mxArray *c1_y = NULL;
  real_T c1_b_u;
  const mxArray *c1_b_y = NULL;
  c1_y = NULL;
  c1_b_u = *((real_T *)c1_u);
  c1_b_y = NULL;
  sf_mex_assign(&c1_b_y, sf_mex_create("y", &c1_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c1_y, c1_b_y);
  return c1_y;
}

const mxArray *sf_c1_conver_PMSM_guangzhou_smo_get_eml_resolved_functions_info
  (void)
{
  const mxArray *c1_nameCaptureInfo = NULL;
  c1_ResolvedFunctionInfo c1_info[25];
  const mxArray *c1_m0 = NULL;
  int32_T c1_i5;
  c1_ResolvedFunctionInfo *c1_r0;
  c1_nameCaptureInfo = NULL;
  c1_info_helper(c1_info);
  sf_mex_assign(&c1_m0, sf_mex_createstruct("nameCaptureInfo", 1, 25));
  for (c1_i5 = 0; c1_i5 < 25; c1_i5 = c1_i5 + 1) {
    c1_r0 = &c1_info[c1_i5];
    sf_mex_addfield(c1_m0, sf_mex_create("nameCaptureInfo", c1_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c1_r0->context)), "context",
                    "nameCaptureInfo", c1_i5);
    sf_mex_addfield(c1_m0, sf_mex_create("nameCaptureInfo", c1_r0->name, 15, 0U,
      0U, 0U, 2, 1, strlen(c1_r0->name)), "name",
                    "nameCaptureInfo", c1_i5);
    sf_mex_addfield(c1_m0, sf_mex_create("nameCaptureInfo", c1_r0->dominantType,
      15, 0U, 0U, 0U, 2, 1, strlen(c1_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c1_i5);
    sf_mex_addfield(c1_m0, sf_mex_create("nameCaptureInfo", c1_r0->resolved, 15,
      0U, 0U, 0U, 2, 1, strlen(c1_r0->resolved)), "resolved"
                    , "nameCaptureInfo", c1_i5);
    sf_mex_addfield(c1_m0, sf_mex_create("nameCaptureInfo", &c1_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c1_i5);
    sf_mex_addfield(c1_m0, sf_mex_create("nameCaptureInfo", &c1_r0->fileTime1, 7,
      0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo", c1_i5);
    sf_mex_addfield(c1_m0, sf_mex_create("nameCaptureInfo", &c1_r0->fileTime2, 7,
      0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo", c1_i5);
  }

  sf_mex_assign(&c1_nameCaptureInfo, c1_m0);
  return c1_nameCaptureInfo;
}

static void c1_info_helper(c1_ResolvedFunctionInfo c1_info[25])
{
  c1_info[0].context = "";
  c1_info[0].name = "gt";
  c1_info[0].dominantType = "double";
  c1_info[0].resolved = "[B]gt";
  c1_info[0].fileLength = 0U;
  c1_info[0].fileTime1 = 0U;
  c1_info[0].fileTime2 = 0U;
  c1_info[1].context = "";
  c1_info[1].name = "sqrt";
  c1_info[1].dominantType = "double";
  c1_info[1].resolved = "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c1_info[1].fileLength = 572U;
  c1_info[1].fileTime1 = 1203422846U;
  c1_info[1].fileTime2 = 0U;
  c1_info[2].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c1_info[2].name = "nargin";
  c1_info[2].dominantType = "";
  c1_info[2].resolved = "[B]nargin";
  c1_info[2].fileLength = 0U;
  c1_info[2].fileTime1 = 0U;
  c1_info[2].fileTime2 = 0U;
  c1_info[3].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c1_info[3].name = "isa";
  c1_info[3].dominantType = "double";
  c1_info[3].resolved = "[B]isa";
  c1_info[3].fileLength = 0U;
  c1_info[3].fileTime1 = 0U;
  c1_info[3].fileTime2 = 0U;
  c1_info[4].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c1_info[4].name = "isreal";
  c1_info[4].dominantType = "double";
  c1_info[4].resolved = "[B]isreal";
  c1_info[4].fileLength = 0U;
  c1_info[4].fileTime1 = 0U;
  c1_info[4].fileTime2 = 0U;
  c1_info[5].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c1_info[5].name = "lt";
  c1_info[5].dominantType = "double";
  c1_info[5].resolved = "[B]lt";
  c1_info[5].fileLength = 0U;
  c1_info[5].fileTime1 = 0U;
  c1_info[5].fileTime2 = 0U;
  c1_info[6].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c1_info[6].name = "eml_error";
  c1_info[6].dominantType = "char";
  c1_info[6].resolved = "[I]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_error.m";
  c1_info[6].fileLength = 315U;
  c1_info[6].fileTime1 = 1213905146U;
  c1_info[6].fileTime2 = 0U;
  c1_info[7].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_error.m";
  c1_info[7].name = "strcmp";
  c1_info[7].dominantType = "char";
  c1_info[7].resolved = "[B]strcmp";
  c1_info[7].fileLength = 0U;
  c1_info[7].fileTime1 = 0U;
  c1_info[7].fileTime2 = 0U;
  c1_info[8].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_error.m";
  c1_info[8].name = "not";
  c1_info[8].dominantType = "logical";
  c1_info[8].resolved = "[B]not";
  c1_info[8].fileLength = 0U;
  c1_info[8].fileTime1 = 0U;
  c1_info[8].fileTime2 = 0U;
  c1_info[9].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m";
  c1_info[9].name = "eml_scalar_sqrt";
  c1_info[9].dominantType = "double";
  c1_info[9].resolved =
    "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sqrt.m";
  c1_info[9].fileLength = 664U;
  c1_info[9].fileTime1 = 1209309194U;
  c1_info[9].fileTime2 = 0U;
  c1_info[10].context = "";
  c1_info[10].name = "mtimes";
  c1_info[10].dominantType = "double";
  c1_info[10].resolved = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c1_info[10].fileLength = 2408U;
  c1_info[10].fileTime1 = 1227588202U;
  c1_info[10].fileTime2 = 0U;
  c1_info[11].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c1_info[11].name = "isinteger";
  c1_info[11].dominantType = "double";
  c1_info[11].resolved = "[B]isinteger";
  c1_info[11].fileLength = 0U;
  c1_info[11].fileTime1 = 0U;
  c1_info[11].fileTime2 = 0U;
  c1_info[12].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c1_info[12].name = "isscalar";
  c1_info[12].dominantType = "double";
  c1_info[12].resolved = "[B]isscalar";
  c1_info[12].fileLength = 0U;
  c1_info[12].fileTime1 = 0U;
  c1_info[12].fileTime2 = 0U;
  c1_info[13].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c1_info[13].name = "size";
  c1_info[13].dominantType = "double";
  c1_info[13].resolved = "[B]size";
  c1_info[13].fileLength = 0U;
  c1_info[13].fileTime1 = 0U;
  c1_info[13].fileTime2 = 0U;
  c1_info[14].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c1_info[14].name = "eq";
  c1_info[14].dominantType = "double";
  c1_info[14].resolved = "[B]eq";
  c1_info[14].fileLength = 0U;
  c1_info[14].fileTime1 = 0U;
  c1_info[14].fileTime2 = 0U;
  c1_info[15].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c1_info[15].name = "class";
  c1_info[15].dominantType = "double";
  c1_info[15].resolved = "[B]class";
  c1_info[15].fileLength = 0U;
  c1_info[15].fileTime1 = 0U;
  c1_info[15].fileTime2 = 0U;
  c1_info[16].context = "";
  c1_info[16].name = "minus";
  c1_info[16].dominantType = "double";
  c1_info[16].resolved = "[B]minus";
  c1_info[16].fileLength = 0U;
  c1_info[16].fileTime1 = 0U;
  c1_info[16].fileTime2 = 0U;
  c1_info[17].context = "";
  c1_info[17].name = "mrdivide";
  c1_info[17].dominantType = "double";
  c1_info[17].resolved = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c1_info[17].fileLength = 771U;
  c1_info[17].fileTime1 = 1219731336U;
  c1_info[17].fileTime2 = 0U;
  c1_info[18].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c1_info[18].name = "ge";
  c1_info[18].dominantType = "double";
  c1_info[18].resolved = "[B]ge";
  c1_info[18].fileLength = 0U;
  c1_info[18].fileTime1 = 0U;
  c1_info[18].fileTime2 = 0U;
  c1_info[19].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c1_info[19].name = "rdivide";
  c1_info[19].dominantType = "double";
  c1_info[19].resolved = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c1_info[19].fileLength = 620U;
  c1_info[19].fileTime1 = 1213905166U;
  c1_info[19].fileTime2 = 0U;
  c1_info[20].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c1_info[20].name = "isempty";
  c1_info[20].dominantType = "double";
  c1_info[20].resolved = "[B]isempty";
  c1_info[20].fileLength = 0U;
  c1_info[20].fileTime1 = 0U;
  c1_info[20].fileTime2 = 0U;
  c1_info[21].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c1_info[21].name = "eml_warning";
  c1_info[21].dominantType = "char";
  c1_info[21].resolved =
    "[I]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_warning.m";
  c1_info[21].fileLength = 274U;
  c1_info[21].fileTime1 = 1227588196U;
  c1_info[21].fileTime2 = 0U;
  c1_info[22].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c1_info[22].name = "eml_div";
  c1_info[22].dominantType = "double";
  c1_info[22].resolved = "[I]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m";
  c1_info[22].fileLength = 4269U;
  c1_info[22].fileTime1 = 1227588186U;
  c1_info[22].fileTime2 = 0U;
  c1_info[23].context = "";
  c1_info[23].name = "uminus";
  c1_info[23].dominantType = "double";
  c1_info[23].resolved = "[B]uminus";
  c1_info[23].fileLength = 0U;
  c1_info[23].fileTime1 = 0U;
  c1_info[23].fileTime2 = 0U;
  c1_info[24].context = "";
  c1_info[24].name = "plus";
  c1_info[24].dominantType = "double";
  c1_info[24].resolved = "[B]plus";
  c1_info[24].fileLength = 0U;
  c1_info[24].fileTime1 = 0U;
  c1_info[24].fileTime2 = 0U;
}

static const mxArray *c1_emlrt_marshallOut(uint8_T c1_u)
{
  const mxArray *c1_y = NULL;
  c1_y = NULL;
  sf_mex_assign(&c1_y, sf_mex_create("y", &c1_u, 3, 0U, 0U, 0U, 0));
  return c1_y;
}

static real_T c1_emlrt_marshallIn(const mxArray *c1_c1, char *c1_name)
{
  real_T c1_y;
  real_T c1_d0;
  sf_mex_import(c1_name, sf_mex_dup(c1_c1), &c1_d0, 1, 0, 0U, 0, 0U, 0);
  c1_y = c1_d0;
  sf_mex_destroy(&c1_c1);
  return c1_y;
}

static real_T c1_b_emlrt_marshallIn(const mxArray *c1_c2, char *c1_name)
{
  real_T c1_y;
  real_T c1_d1;
  sf_mex_import(c1_name, sf_mex_dup(c1_c2), &c1_d1, 1, 0, 0U, 0, 0U, 0);
  c1_y = c1_d1;
  sf_mex_destroy(&c1_c2);
  return c1_y;
}

static real_T c1_c_emlrt_marshallIn(const mxArray *c1_c3, char *c1_name)
{
  real_T c1_y;
  real_T c1_d2;
  sf_mex_import(c1_name, sf_mex_dup(c1_c3), &c1_d2, 1, 0, 0U, 0, 0U, 0);
  c1_y = c1_d2;
  sf_mex_destroy(&c1_c3);
  return c1_y;
}

static uint8_T c1_d_emlrt_marshallIn(const mxArray
  *c1_b_is_active_c1_conver_PMSM_guangzhou_smo, char *c1_name)
{
  uint8_T c1_y;
  uint8_T c1_u0;
  sf_mex_import(c1_name, sf_mex_dup(c1_b_is_active_c1_conver_PMSM_guangzhou_smo),
                &c1_u0, 1, 3, 0U, 0, 0U, 0);
  c1_y = c1_u0;
  sf_mex_destroy(&c1_b_is_active_c1_conver_PMSM_guangzhou_smo);
  return c1_y;
}

static void init_io_bus_offset(void)
{
}

static void init_dsm_address_info(void)
{
}

/* SFunction Glue Code */
void sf_c1_conver_PMSM_guangzhou_smo_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(2529651140U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3977143546U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(928375213U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(788524491U);
}

mxArray *sf_c1_conver_PMSM_guangzhou_smo_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(2202053924U);
    pr[1] = (double)(1786352194U);
    pr[2] = (double)(3089261094U);
    pr[3] = (double)(3281561766U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,3,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(2);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,3,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c1_conver_PMSM_guangzhou_smo(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  char *infoEncStr[] = {
    "100 S1x4'type','srcId','name','auxInfo'{{M[1],M[5],T\"c1\",},{M[1],M[8],T\"c2\",},{M[1],M[9],T\"c3\",},{M[8],M[0],T\"is_active_c1_conver_PMSM_guangzhou_smo\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 4, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c1_conver_PMSM_guangzhou_smo_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_conver_PMSM_guangzhou_smoMachineNumber_,
           1,
           1,
           1,
           6,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance.chartNumber),
           &(chartInstance.instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation
            (_conver_PMSM_guangzhou_smoMachineNumber_,chartInstance.chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_conver_PMSM_guangzhou_smoMachineNumber_,chartInstance.chartNumber,
             1);
          sf_debug_set_chart_event_thresholds
            (_conver_PMSM_guangzhou_smoMachineNumber_,
             chartInstance.chartNumber,
             0,
             0,
             0);

          {
            unsigned int dimVector[1];
            dimVector[0]= 2;
            _SFD_SET_DATA_PROPS(0,1,1,0,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"u",0,c1_sf_marshall);
          }

          _SFD_SET_DATA_PROPS(1,2,0,1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"c1",0,
                              NULL);
          _SFD_SET_DATA_PROPS(2,1,1,0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"Ts",0,
                              c1_b_sf_marshall);
          _SFD_SET_DATA_PROPS(3,1,1,0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"Ud",0,
                              NULL);
          _SFD_SET_DATA_PROPS(4,2,0,1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"c2",0,
                              NULL);
          _SFD_SET_DATA_PROPS(5,2,0,1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"c3",0,
                              NULL);
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,1,14,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,802);
        _SFD_CV_INIT_EML_IF(0,0,44,52,62,79);
        _SFD_CV_INIT_EML_IF(0,1,106,114,124,141);
        _SFD_CV_INIT_EML_IF(0,2,169,177,187,204);
        _SFD_CV_INIT_EML_IF(0,3,307,315,332,466);
        _SFD_CV_INIT_EML_IF(0,4,332,344,360,466);
        _SFD_CV_INIT_EML_IF(0,5,360,372,389,466);
        _SFD_CV_INIT_EML_IF(0,6,389,401,415,466);
        _SFD_CV_INIT_EML_IF(0,7,415,427,445,466);
        _SFD_CV_INIT_EML_IF(0,8,467,481,523,554);
        _SFD_CV_INIT_EML_IF(0,9,600,608,632,802);
        _SFD_CV_INIT_EML_IF(0,10,632,644,668,802);
        _SFD_CV_INIT_EML_IF(0,11,668,680,704,802);
        _SFD_CV_INIT_EML_IF(0,12,704,716,737,802);
        _SFD_CV_INIT_EML_IF(0,13,737,749,773,802);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          real_T (*c1_u)[2];
          real_T *c1_c1;
          real_T *c1_Ts;
          real_T *c1_Ud;
          real_T *c1_c2;
          real_T *c1_c3;
          c1_Ts = (real_T *)ssGetInputPortSignal(chartInstance.S, 1);
          c1_c3 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 3);
          c1_c1 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
          c1_c2 = (real_T *)ssGetOutputPortSignal(chartInstance.S, 2);
          c1_u = (real_T (*)[2])ssGetInputPortSignal(chartInstance.S, 0);
          c1_Ud = (real_T *)ssGetInputPortSignal(chartInstance.S, 2);
          _SFD_SET_DATA_VALUE_PTR(0U, c1_u);
          _SFD_SET_DATA_VALUE_PTR(1U, c1_c1);
          _SFD_SET_DATA_VALUE_PTR(2U, c1_Ts);
          _SFD_SET_DATA_VALUE_PTR(3U, c1_Ud);
          _SFD_SET_DATA_VALUE_PTR(4U, c1_c2);
          _SFD_SET_DATA_VALUE_PTR(5U, c1_c3);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration
        (_conver_PMSM_guangzhou_smoMachineNumber_,chartInstance.chartNumber,
         chartInstance.instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c1_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  chart_debug_initialization(chartInstance.S,0);
  initialize_params_c1_conver_PMSM_guangzhou_smo();
  initialize_c1_conver_PMSM_guangzhou_smo();
}

static void sf_opaque_enable_c1_conver_PMSM_guangzhou_smo(void *chartInstanceVar)
{
  enable_c1_conver_PMSM_guangzhou_smo();
}

static void sf_opaque_disable_c1_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  disable_c1_conver_PMSM_guangzhou_smo();
}

static void sf_opaque_gateway_c1_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  sf_c1_conver_PMSM_guangzhou_smo();
}

static mxArray* sf_opaque_get_sim_state_c1_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  mxArray *st = (mxArray *) get_sim_state_c1_conver_PMSM_guangzhou_smo();
  return st;
}

static void sf_opaque_set_sim_state_c1_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar, const mxArray *st)
{
  set_sim_state_c1_conver_PMSM_guangzhou_smo(sf_mex_dup(st));
}

static void sf_opaque_terminate_c1_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  if (sim_mode_is_rtw_gen(chartInstance.S) || sim_mode_is_external
      (chartInstance.S)) {
    sf_clear_rtw_identifier(chartInstance.S);
  }

  finalize_c1_conver_PMSM_guangzhou_smo();
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c1_conver_PMSM_guangzhou_smo(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c1_conver_PMSM_guangzhou_smo();
  }
}

static void mdlSetWorkWidths_c1_conver_PMSM_guangzhou_smo(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("conver_PMSM_guangzhou_smo",
      "conver_PMSM_guangzhou_smo",1);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("conver_PMSM_guangzhou_smo",
                "conver_PMSM_guangzhou_smo",1,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop(
      "conver_PMSM_guangzhou_smo","conver_PMSM_guangzhou_smo",1,
      "gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"conver_PMSM_guangzhou_smo",
        "conver_PMSM_guangzhou_smo",1,3);
      sf_mark_chart_reusable_outputs(S,"conver_PMSM_guangzhou_smo",
        "conver_PMSM_guangzhou_smo",1,3);
    }

    sf_set_rtw_dwork_info(S,"conver_PMSM_guangzhou_smo",
                          "conver_PMSM_guangzhou_smo",1);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(485114194U));
  ssSetChecksum1(S,(496314650U));
  ssSetChecksum2(S,(3015259084U));
  ssSetChecksum3(S,(2657421697U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c1_conver_PMSM_guangzhou_smo(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "conver_PMSM_guangzhou_smo",
      "conver_PMSM_guangzhou_smo",1);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c1_conver_PMSM_guangzhou_smo(SimStruct *S)
{
  chartInstance.chartInfo.chartInstance = NULL;
  chartInstance.chartInfo.isEMLChart = 1;
  chartInstance.chartInfo.chartInitialized = 0;
  chartInstance.chartInfo.sFunctionGateway =
    sf_opaque_gateway_c1_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.initializeChart =
    sf_opaque_initialize_c1_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.terminateChart =
    sf_opaque_terminate_c1_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.enableChart =
    sf_opaque_enable_c1_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.disableChart =
    sf_opaque_disable_c1_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.getSimState =
    sf_opaque_get_sim_state_c1_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.setSimState =
    sf_opaque_set_sim_state_c1_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c1_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.zeroCrossings = NULL;
  chartInstance.chartInfo.outputs = NULL;
  chartInstance.chartInfo.derivatives = NULL;
  chartInstance.chartInfo.mdlRTW = mdlRTW_c1_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.mdlStart = mdlStart_c1_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c1_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.extModeExec = NULL;
  chartInstance.chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance.chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance.chartInfo.storeCurrentConfiguration = NULL;
  chartInstance.S = S;
  ssSetUserData(S,(void *)(&(chartInstance.chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info();
  }

  chart_debug_initialization(S,1);
}

void c1_conver_PMSM_guangzhou_smo_method_dispatcher(SimStruct *S, int_T method,
  void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c1_conver_PMSM_guangzhou_smo(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c1_conver_PMSM_guangzhou_smo(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c1_conver_PMSM_guangzhou_smo(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c1_conver_PMSM_guangzhou_smo_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
