/* Include files */

#include "blascompat32.h"
#include "conver_PMSM_guangzhou_smo_sfun.h"
#include "c3_conver_PMSM_guangzhou_smo.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance.chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance.instanceNumber)
#include "conver_PMSM_guangzhou_smo_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */
#define c3_IN_NO_ACTIVE_CHILD          (0)

/* Variable Declarations */

/* Variable Definitions */
static SFc3_conver_PMSM_guangzhou_smoInstanceStruct chartInstance;

/* Function Declarations */
static void initialize_c3_conver_PMSM_guangzhou_smo(void);
static void initialize_params_c3_conver_PMSM_guangzhou_smo(void);
static void enable_c3_conver_PMSM_guangzhou_smo(void);
static void disable_c3_conver_PMSM_guangzhou_smo(void);
static void c3_update_debugger_state_c3_conver_PMSM_guangzhou_smo(void);
static const mxArray *get_sim_state_c3_conver_PMSM_guangzhou_smo(void);
static void set_sim_state_c3_conver_PMSM_guangzhou_smo(const mxArray *c3_st);
static void finalize_c3_conver_PMSM_guangzhou_smo(void);
static void sf_c3_conver_PMSM_guangzhou_smo(void);
static void init_script_number_translation(uint32_T c3_machineNumber, uint32_T
  c3_chartNumber);
static const mxArray *c3_sf_marshall(void *c3_chartInstance, void *c3_u);
static void c3_info_helper(c3_ResolvedFunctionInfo c3_info[18]);
static const mxArray *c3_emlrt_marshallOut(uint8_T c3_u);
static real_T c3_emlrt_marshallIn(const mxArray *c3_a, char *c3_name);
static real_T c3_b_emlrt_marshallIn(const mxArray *c3_b, char *c3_name);
static uint8_T c3_c_emlrt_marshallIn(const mxArray
  *c3_b_is_active_c3_conver_PMSM_guangzhou_smo, char *c3_name);
static void init_io_bus_offset(void);
static void init_dsm_address_info(void);

/* Function Definitions */
static void initialize_c3_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
  chartInstance.c3_is_active_c3_conver_PMSM_guangzhou_smo = 0U;
}

static void initialize_params_c3_conver_PMSM_guangzhou_smo(void)
{
}

static void enable_c3_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
}

static void disable_c3_conver_PMSM_guangzhou_smo(void)
{
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
}

static void c3_update_debugger_state_c3_conver_PMSM_guangzhou_smo(void)
{
}

static const mxArray *get_sim_state_c3_conver_PMSM_guangzhou_smo(void)
{
  const mxArray *c3_st = NULL;
  const mxArray *c3_y = NULL;
  real_T c3_u;
  const mxArray *c3_b_y = NULL;
  real_T c3_b_u;
  const mxArray *c3_c_y = NULL;
  real_T *c3_a;
  real_T *c3_b;
  c3_b = (real_T *)ssGetOutputPortSignal(chartInstance.S, 2);
  c3_a = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  c3_st = NULL;
  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_createcellarray(3));
  c3_u = *c3_a;
  c3_b_y = NULL;
  sf_mex_assign(&c3_b_y, sf_mex_create("y", &c3_u, 0, 0U, 0U, 0U, 0));
  sf_mex_setcell(c3_y, 0, c3_b_y);
  c3_b_u = *c3_b;
  c3_c_y = NULL;
  sf_mex_assign(&c3_c_y, sf_mex_create("y", &c3_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_setcell(c3_y, 1, c3_c_y);
  sf_mex_setcell(c3_y, 2, c3_emlrt_marshallOut
                 (chartInstance.c3_is_active_c3_conver_PMSM_guangzhou_smo));
  sf_mex_assign(&c3_st, c3_y);
  return c3_st;
}

static void set_sim_state_c3_conver_PMSM_guangzhou_smo(const mxArray *c3_st)
{
  const mxArray *c3_u;
  real_T *c3_a;
  real_T *c3_b;
  c3_b = (real_T *)ssGetOutputPortSignal(chartInstance.S, 2);
  c3_a = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  chartInstance.c3_doneDoubleBufferReInit = true;
  c3_u = sf_mex_dup(c3_st);
  *c3_a = c3_emlrt_marshallIn(sf_mex_dup(sf_mex_getcell(c3_u, 0)), "a");
  *c3_b = c3_b_emlrt_marshallIn(sf_mex_dup(sf_mex_getcell(c3_u, 1)), "b");
  chartInstance.c3_is_active_c3_conver_PMSM_guangzhou_smo =
    c3_c_emlrt_marshallIn(sf_mex_dup(sf_mex_getcell(c3_u, 2)),
    "is_active_c3_conver_PMSM_guangzhou_smo");
  sf_mex_destroy(&c3_u);
  c3_update_debugger_state_c3_conver_PMSM_guangzhou_smo();
  sf_mex_destroy(&c3_st);
}

static void finalize_c3_conver_PMSM_guangzhou_smo(void)
{
}

static void sf_c3_conver_PMSM_guangzhou_smo(void)
{
  uint8_T c3_previousEvent;
  real_T c3_q;
  real_T c3_the;
  real_T c3_d;
  real_T c3_nargout = 2.0;
  real_T c3_nargin = 3.0;
  real_T c3_b;
  real_T c3_a;
  real_T c3_b_a;
  real_T c3_x;
  real_T c3_b_b;
  real_T c3_b_x;
  real_T c3_y;
  real_T c3_c_a;
  real_T c3_c_x;
  real_T c3_c_b;
  real_T c3_d_x;
  real_T c3_b_y;
  real_T c3_d_a;
  real_T c3_e_x;
  real_T c3_d_b;
  real_T c3_f_x;
  real_T c3_c_y;
  real_T c3_e_a;
  real_T c3_g_x;
  real_T c3_e_b;
  real_T c3_h_x;
  real_T c3_d_y;
  real_T *c3_b_q;
  real_T *c3_b_the;
  real_T *c3_b_d;
  real_T *c3_f_a;
  real_T *c3_f_b;
  c3_b_q = (real_T *)ssGetInputPortSignal(chartInstance.S, 0);
  c3_b_d = (real_T *)ssGetInputPortSignal(chartInstance.S, 2);
  c3_b_the = (real_T *)ssGetInputPortSignal(chartInstance.S, 1);
  c3_f_b = (real_T *)ssGetOutputPortSignal(chartInstance.S, 2);
  c3_f_a = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
  _sfTime_ = (real_T)ssGetT(chartInstance.S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,2);
  _SFD_DATA_RANGE_CHECK(*c3_b_q, 0U);
  _SFD_DATA_RANGE_CHECK(*c3_b_the, 1U);
  _SFD_DATA_RANGE_CHECK(*c3_b_d, 2U);
  _SFD_DATA_RANGE_CHECK(*c3_f_a, 3U);
  _SFD_DATA_RANGE_CHECK(*c3_f_b, 4U);
  c3_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,2);
  c3_q = *c3_b_q;
  c3_the = *c3_b_the;
  c3_d = *c3_b_d;
  sf_debug_symbol_scope_push(7U, 0U);
  sf_debug_symbol_scope_add("nargout", &c3_nargout, c3_sf_marshall);
  sf_debug_symbol_scope_add("nargin", &c3_nargin, c3_sf_marshall);
  sf_debug_symbol_scope_add("b", &c3_b, c3_sf_marshall);
  sf_debug_symbol_scope_add("a", &c3_a, c3_sf_marshall);
  sf_debug_symbol_scope_add("d", &c3_d, c3_sf_marshall);
  sf_debug_symbol_scope_add("the", &c3_the, c3_sf_marshall);
  sf_debug_symbol_scope_add("q", &c3_q, c3_sf_marshall);
  CV_EML_FCN(0, 0);
  _SFD_EML_CALL(0,2);
  c3_b_a = c3_q;
  c3_x = c3_the;
  c3_b_b = c3_x;
  c3_b_x = c3_b_b;
  c3_b_b = c3_b_x;
  c3_b_b = muDoubleScalarSin(c3_b_b);
  c3_y = c3_b_a * c3_b_b;
  c3_c_a = c3_d;
  c3_c_x = c3_the;
  c3_c_b = c3_c_x;
  c3_d_x = c3_c_b;
  c3_c_b = c3_d_x;
  c3_c_b = muDoubleScalarCos(c3_c_b);
  c3_b_y = c3_c_a * c3_c_b;
  c3_a = c3_b_y - c3_y;
  _SFD_EML_CALL(0,3);
  c3_d_a = c3_q;
  c3_e_x = c3_the;
  c3_d_b = c3_e_x;
  c3_f_x = c3_d_b;
  c3_d_b = c3_f_x;
  c3_d_b = muDoubleScalarCos(c3_d_b);
  c3_c_y = c3_d_a * c3_d_b;
  c3_e_a = c3_d;
  c3_g_x = c3_the;
  c3_e_b = c3_g_x;
  c3_h_x = c3_e_b;
  c3_e_b = c3_h_x;
  c3_e_b = muDoubleScalarSin(c3_e_b);
  c3_d_y = c3_e_a * c3_e_b;
  c3_b = c3_d_y + c3_c_y;
  _SFD_EML_CALL(0,-3);
  sf_debug_symbol_scope_pop();
  *c3_f_a = c3_a;
  *c3_f_b = c3_b;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,2);
  _sfEvent_ = c3_previousEvent;
  sf_debug_check_for_state_inconsistency
    (_conver_PMSM_guangzhou_smoMachineNumber_, chartInstance.chartNumber,
     chartInstance.
     instanceNumber);
}

static void init_script_number_translation(uint32_T c3_machineNumber, uint32_T
  c3_chartNumber)
{
}

static const mxArray *c3_sf_marshall(void *c3_chartInstance, void *c3_u)
{
  const mxArray *c3_y = NULL;
  real_T c3_b_u;
  const mxArray *c3_b_y = NULL;
  c3_y = NULL;
  c3_b_u = *((real_T *)c3_u);
  c3_b_y = NULL;
  sf_mex_assign(&c3_b_y, sf_mex_create("y", &c3_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c3_y, c3_b_y);
  return c3_y;
}

const mxArray *sf_c3_conver_PMSM_guangzhou_smo_get_eml_resolved_functions_info
  (void)
{
  const mxArray *c3_nameCaptureInfo = NULL;
  c3_ResolvedFunctionInfo c3_info[18];
  const mxArray *c3_m0 = NULL;
  int32_T c3_i0;
  c3_ResolvedFunctionInfo *c3_r0;
  c3_nameCaptureInfo = NULL;
  c3_info_helper(c3_info);
  sf_mex_assign(&c3_m0, sf_mex_createstruct("nameCaptureInfo", 1, 18));
  for (c3_i0 = 0; c3_i0 < 18; c3_i0 = c3_i0 + 1) {
    c3_r0 = &c3_info[c3_i0];
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", c3_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c3_r0->context)), "context",
                    "nameCaptureInfo", c3_i0);
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", c3_r0->name, 15, 0U,
      0U, 0U, 2, 1, strlen(c3_r0->name)), "name",
                    "nameCaptureInfo", c3_i0);
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", c3_r0->dominantType,
      15, 0U, 0U, 0U, 2, 1, strlen(c3_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c3_i0);
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", c3_r0->resolved, 15,
      0U, 0U, 0U, 2, 1, strlen(c3_r0->resolved)), "resolved"
                    , "nameCaptureInfo", c3_i0);
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", &c3_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c3_i0);
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", &c3_r0->fileTime1, 7,
      0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo", c3_i0);
    sf_mex_addfield(c3_m0, sf_mex_create("nameCaptureInfo", &c3_r0->fileTime2, 7,
      0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo", c3_i0);
  }

  sf_mex_assign(&c3_nameCaptureInfo, c3_m0);
  return c3_nameCaptureInfo;
}

static void c3_info_helper(c3_ResolvedFunctionInfo c3_info[18])
{
  c3_info[0].context = "";
  c3_info[0].name = "cos";
  c3_info[0].dominantType = "double";
  c3_info[0].resolved = "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c3_info[0].fileLength = 324U;
  c3_info[0].fileTime1 = 1203422752U;
  c3_info[0].fileTime2 = 0U;
  c3_info[1].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c3_info[1].name = "nargin";
  c3_info[1].dominantType = "";
  c3_info[1].resolved = "[B]nargin";
  c3_info[1].fileLength = 0U;
  c3_info[1].fileTime1 = 0U;
  c3_info[1].fileTime2 = 0U;
  c3_info[2].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c3_info[2].name = "gt";
  c3_info[2].dominantType = "double";
  c3_info[2].resolved = "[B]gt";
  c3_info[2].fileLength = 0U;
  c3_info[2].fileTime1 = 0U;
  c3_info[2].fileTime2 = 0U;
  c3_info[3].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c3_info[3].name = "isa";
  c3_info[3].dominantType = "double";
  c3_info[3].resolved = "[B]isa";
  c3_info[3].fileLength = 0U;
  c3_info[3].fileTime1 = 0U;
  c3_info[3].fileTime2 = 0U;
  c3_info[4].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m";
  c3_info[4].name = "eml_scalar_cos";
  c3_info[4].dominantType = "double";
  c3_info[4].resolved =
    "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_cos.m";
  c3_info[4].fileLength = 602U;
  c3_info[4].fileTime1 = 1209309188U;
  c3_info[4].fileTime2 = 0U;
  c3_info[5].context =
    "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_cos.m";
  c3_info[5].name = "isreal";
  c3_info[5].dominantType = "double";
  c3_info[5].resolved = "[B]isreal";
  c3_info[5].fileLength = 0U;
  c3_info[5].fileTime1 = 0U;
  c3_info[5].fileTime2 = 0U;
  c3_info[6].context = "";
  c3_info[6].name = "mtimes";
  c3_info[6].dominantType = "double";
  c3_info[6].resolved = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c3_info[6].fileLength = 2408U;
  c3_info[6].fileTime1 = 1227588202U;
  c3_info[6].fileTime2 = 0U;
  c3_info[7].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c3_info[7].name = "isinteger";
  c3_info[7].dominantType = "double";
  c3_info[7].resolved = "[B]isinteger";
  c3_info[7].fileLength = 0U;
  c3_info[7].fileTime1 = 0U;
  c3_info[7].fileTime2 = 0U;
  c3_info[8].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c3_info[8].name = "isscalar";
  c3_info[8].dominantType = "double";
  c3_info[8].resolved = "[B]isscalar";
  c3_info[8].fileLength = 0U;
  c3_info[8].fileTime1 = 0U;
  c3_info[8].fileTime2 = 0U;
  c3_info[9].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c3_info[9].name = "strcmp";
  c3_info[9].dominantType = "char";
  c3_info[9].resolved = "[B]strcmp";
  c3_info[9].fileLength = 0U;
  c3_info[9].fileTime1 = 0U;
  c3_info[9].fileTime2 = 0U;
  c3_info[10].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c3_info[10].name = "size";
  c3_info[10].dominantType = "double";
  c3_info[10].resolved = "[B]size";
  c3_info[10].fileLength = 0U;
  c3_info[10].fileTime1 = 0U;
  c3_info[10].fileTime2 = 0U;
  c3_info[11].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c3_info[11].name = "eq";
  c3_info[11].dominantType = "double";
  c3_info[11].resolved = "[B]eq";
  c3_info[11].fileLength = 0U;
  c3_info[11].fileTime1 = 0U;
  c3_info[11].fileTime2 = 0U;
  c3_info[12].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c3_info[12].name = "class";
  c3_info[12].dominantType = "double";
  c3_info[12].resolved = "[B]class";
  c3_info[12].fileLength = 0U;
  c3_info[12].fileTime1 = 0U;
  c3_info[12].fileTime2 = 0U;
  c3_info[13].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c3_info[13].name = "not";
  c3_info[13].dominantType = "logical";
  c3_info[13].resolved = "[B]not";
  c3_info[13].fileLength = 0U;
  c3_info[13].fileTime1 = 0U;
  c3_info[13].fileTime2 = 0U;
  c3_info[14].context = "";
  c3_info[14].name = "sin";
  c3_info[14].dominantType = "double";
  c3_info[14].resolved = "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m";
  c3_info[14].fileLength = 324U;
  c3_info[14].fileTime1 = 1203422842U;
  c3_info[14].fileTime2 = 0U;
  c3_info[15].context = "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m";
  c3_info[15].name = "eml_scalar_sin";
  c3_info[15].dominantType = "double";
  c3_info[15].resolved =
    "[I]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sin.m";
  c3_info[15].fileLength = 601U;
  c3_info[15].fileTime1 = 1209309192U;
  c3_info[15].fileTime2 = 0U;
  c3_info[16].context = "";
  c3_info[16].name = "minus";
  c3_info[16].dominantType = "double";
  c3_info[16].resolved = "[B]minus";
  c3_info[16].fileLength = 0U;
  c3_info[16].fileTime1 = 0U;
  c3_info[16].fileTime2 = 0U;
  c3_info[17].context = "";
  c3_info[17].name = "plus";
  c3_info[17].dominantType = "double";
  c3_info[17].resolved = "[B]plus";
  c3_info[17].fileLength = 0U;
  c3_info[17].fileTime1 = 0U;
  c3_info[17].fileTime2 = 0U;
}

static const mxArray *c3_emlrt_marshallOut(uint8_T c3_u)
{
  const mxArray *c3_y = NULL;
  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_create("y", &c3_u, 3, 0U, 0U, 0U, 0));
  return c3_y;
}

static real_T c3_emlrt_marshallIn(const mxArray *c3_a, char *c3_name)
{
  real_T c3_y;
  real_T c3_d0;
  sf_mex_import(c3_name, sf_mex_dup(c3_a), &c3_d0, 1, 0, 0U, 0, 0U, 0);
  c3_y = c3_d0;
  sf_mex_destroy(&c3_a);
  return c3_y;
}

static real_T c3_b_emlrt_marshallIn(const mxArray *c3_b, char *c3_name)
{
  real_T c3_y;
  real_T c3_d1;
  sf_mex_import(c3_name, sf_mex_dup(c3_b), &c3_d1, 1, 0, 0U, 0, 0U, 0);
  c3_y = c3_d1;
  sf_mex_destroy(&c3_b);
  return c3_y;
}

static uint8_T c3_c_emlrt_marshallIn(const mxArray
  *c3_b_is_active_c3_conver_PMSM_guangzhou_smo, char *c3_name)
{
  uint8_T c3_y;
  uint8_T c3_u0;
  sf_mex_import(c3_name, sf_mex_dup(c3_b_is_active_c3_conver_PMSM_guangzhou_smo),
                &c3_u0, 1, 3, 0U, 0, 0U, 0);
  c3_y = c3_u0;
  sf_mex_destroy(&c3_b_is_active_c3_conver_PMSM_guangzhou_smo);
  return c3_y;
}

static void init_io_bus_offset(void)
{
}

static void init_dsm_address_info(void)
{
}

/* SFunction Glue Code */
void sf_c3_conver_PMSM_guangzhou_smo_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1078722591U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(2325658902U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(2761929630U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(2671831878U);
}

mxArray *sf_c3_conver_PMSM_guangzhou_smo_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(1747599626U);
    pr[1] = (double)(2830474911U);
    pr[2] = (double)(275071189U);
    pr[3] = (double)(3532942779U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,3,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,2,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c3_conver_PMSM_guangzhou_smo(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  char *infoEncStr[] = {
    "100 S1x3'type','srcId','name','auxInfo'{{M[1],M[7],T\"a\",},{M[1],M[8],T\"b\",},{M[8],M[0],T\"is_active_c3_conver_PMSM_guangzhou_smo\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 3, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c3_conver_PMSM_guangzhou_smo_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_conver_PMSM_guangzhou_smoMachineNumber_,
           3,
           1,
           1,
           5,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance.chartNumber),
           &(chartInstance.instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation
            (_conver_PMSM_guangzhou_smoMachineNumber_,chartInstance.chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_conver_PMSM_guangzhou_smoMachineNumber_,chartInstance.chartNumber,
             1);
          sf_debug_set_chart_event_thresholds
            (_conver_PMSM_guangzhou_smoMachineNumber_,
             chartInstance.chartNumber,
             0,
             0,
             0);
          _SFD_SET_DATA_PROPS(0,1,1,0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"q",0,
                              c3_sf_marshall);
          _SFD_SET_DATA_PROPS(1,1,1,0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"the",0,
                              NULL);
          _SFD_SET_DATA_PROPS(2,1,1,0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"d",0,
                              NULL);
          _SFD_SET_DATA_PROPS(3,2,0,1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"a",0,
                              NULL);
          _SFD_SET_DATA_PROPS(4,2,0,1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"b",0,
                              NULL);
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,1,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,79);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          real_T *c3_q;
          real_T *c3_the;
          real_T *c3_d;
          real_T *c3_a;
          real_T *c3_b;
          c3_q = (real_T *)ssGetInputPortSignal(chartInstance.S, 0);
          c3_d = (real_T *)ssGetInputPortSignal(chartInstance.S, 2);
          c3_the = (real_T *)ssGetInputPortSignal(chartInstance.S, 1);
          c3_b = (real_T *)ssGetOutputPortSignal(chartInstance.S, 2);
          c3_a = (real_T *)ssGetOutputPortSignal(chartInstance.S, 1);
          _SFD_SET_DATA_VALUE_PTR(0U, c3_q);
          _SFD_SET_DATA_VALUE_PTR(1U, c3_the);
          _SFD_SET_DATA_VALUE_PTR(2U, c3_d);
          _SFD_SET_DATA_VALUE_PTR(3U, c3_a);
          _SFD_SET_DATA_VALUE_PTR(4U, c3_b);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration
        (_conver_PMSM_guangzhou_smoMachineNumber_,chartInstance.chartNumber,
         chartInstance.instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c3_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  chart_debug_initialization(chartInstance.S,0);
  initialize_params_c3_conver_PMSM_guangzhou_smo();
  initialize_c3_conver_PMSM_guangzhou_smo();
}

static void sf_opaque_enable_c3_conver_PMSM_guangzhou_smo(void *chartInstanceVar)
{
  enable_c3_conver_PMSM_guangzhou_smo();
}

static void sf_opaque_disable_c3_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  disable_c3_conver_PMSM_guangzhou_smo();
}

static void sf_opaque_gateway_c3_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  sf_c3_conver_PMSM_guangzhou_smo();
}

static mxArray* sf_opaque_get_sim_state_c3_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  mxArray *st = (mxArray *) get_sim_state_c3_conver_PMSM_guangzhou_smo();
  return st;
}

static void sf_opaque_set_sim_state_c3_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar, const mxArray *st)
{
  set_sim_state_c3_conver_PMSM_guangzhou_smo(sf_mex_dup(st));
}

static void sf_opaque_terminate_c3_conver_PMSM_guangzhou_smo(void
  *chartInstanceVar)
{
  if (sim_mode_is_rtw_gen(chartInstance.S) || sim_mode_is_external
      (chartInstance.S)) {
    sf_clear_rtw_identifier(chartInstance.S);
  }

  finalize_c3_conver_PMSM_guangzhou_smo();
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c3_conver_PMSM_guangzhou_smo(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c3_conver_PMSM_guangzhou_smo();
  }
}

static void mdlSetWorkWidths_c3_conver_PMSM_guangzhou_smo(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("conver_PMSM_guangzhou_smo",
      "conver_PMSM_guangzhou_smo",3);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("conver_PMSM_guangzhou_smo",
                "conver_PMSM_guangzhou_smo",3,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop(
      "conver_PMSM_guangzhou_smo","conver_PMSM_guangzhou_smo",3,
      "gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"conver_PMSM_guangzhou_smo",
        "conver_PMSM_guangzhou_smo",3,3);
      sf_mark_chart_reusable_outputs(S,"conver_PMSM_guangzhou_smo",
        "conver_PMSM_guangzhou_smo",3,2);
    }

    sf_set_rtw_dwork_info(S,"conver_PMSM_guangzhou_smo",
                          "conver_PMSM_guangzhou_smo",3);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(3854177582U));
  ssSetChecksum1(S,(2899012348U));
  ssSetChecksum2(S,(4149819427U));
  ssSetChecksum3(S,(1646673624U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c3_conver_PMSM_guangzhou_smo(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "conver_PMSM_guangzhou_smo",
      "conver_PMSM_guangzhou_smo",3);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c3_conver_PMSM_guangzhou_smo(SimStruct *S)
{
  chartInstance.chartInfo.chartInstance = NULL;
  chartInstance.chartInfo.isEMLChart = 1;
  chartInstance.chartInfo.chartInitialized = 0;
  chartInstance.chartInfo.sFunctionGateway =
    sf_opaque_gateway_c3_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.initializeChart =
    sf_opaque_initialize_c3_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.terminateChart =
    sf_opaque_terminate_c3_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.enableChart =
    sf_opaque_enable_c3_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.disableChart =
    sf_opaque_disable_c3_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.getSimState =
    sf_opaque_get_sim_state_c3_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.setSimState =
    sf_opaque_set_sim_state_c3_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c3_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.zeroCrossings = NULL;
  chartInstance.chartInfo.outputs = NULL;
  chartInstance.chartInfo.derivatives = NULL;
  chartInstance.chartInfo.mdlRTW = mdlRTW_c3_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.mdlStart = mdlStart_c3_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c3_conver_PMSM_guangzhou_smo;
  chartInstance.chartInfo.extModeExec = NULL;
  chartInstance.chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance.chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance.chartInfo.storeCurrentConfiguration = NULL;
  chartInstance.S = S;
  ssSetUserData(S,(void *)(&(chartInstance.chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info();
  }

  chart_debug_initialization(S,1);
}

void c3_conver_PMSM_guangzhou_smo_method_dispatcher(SimStruct *S, int_T method,
  void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c3_conver_PMSM_guangzhou_smo(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c3_conver_PMSM_guangzhou_smo(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c3_conver_PMSM_guangzhou_smo(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c3_conver_PMSM_guangzhou_smo_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
