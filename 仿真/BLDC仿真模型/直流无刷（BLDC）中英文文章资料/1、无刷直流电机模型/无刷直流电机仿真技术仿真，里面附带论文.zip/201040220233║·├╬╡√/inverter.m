function sys=mdlOutputs(t,x,u)
if u>=0&u<pi/3
    sys=[1 0 0 1 0 0];
elseif u>=pi/3&u<2*pi/3
    sys=[1 0 0 0 0 1];
elseif u>=2*pi/3&u<pi
    sys=[0 0 1 0 0 1];
elseif u>=pi&u<4*pi/3
    sys=[0?1?1?0?0?0];?
elseif u>=4*pi/3&u<5*pi/3
    sys=[0 1 0 0 1 0];
else
sys=[0 0 0 1 1 0];
end